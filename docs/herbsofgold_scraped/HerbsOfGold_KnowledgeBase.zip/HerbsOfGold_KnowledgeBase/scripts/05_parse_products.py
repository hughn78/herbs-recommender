#!/usr/bin/env python3
"""05_parse_products.py — Parse each product's structured fields from DOCX sections.

For every product, extracts:
  - AUSTL              (note: AUSTL not present in this manual — see notes)
  - DosageForm         (capsule / tablet / liquid / powder / cream / spray)
  - PackSize           (e.g. "60 / 120 capsules")
  - Ingredients        (parsed from "Each X contains:" line)
  - AdultDose / ChildDose / Directions (from "DIRECTIONS FOR USE")
  - Indications        (from intro paragraph + Features & Benefits)
  - Cautions / Contraindications / Interactions / Side effects
  - Pregnancy/breastfeeding notes
  - Source page (from TOC)
  - ExtractionConfidence
  - Issues
"""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import (
    INTERMEDIATE, OUTPUT, get_logger, normalise_name, make_product_id,
    AUSTL_RE, STRENGTH_RE, BRAND, classify_ingredient,
)
from _lib import normalise_name as _norm

log = get_logger("05_parse_products")

# -- Regex for dosage form detection --
DOSAGE_FORM_RE = re.compile(
    r"\b(capsules?|tablets?|soft\s*gel(?:s)?|liquid|tonic|drop[s]?|spray|cream|gel|"
    r"powder|sachets?|lozenges?|chewable|vege\s*caps?|vegicap[s]?|film[-\s]*coated|"
    r"sublingual|oral)\b",
    re.IGNORECASE,
)
DOSAGE_FORM_MAP = {
    "capsule": "capsule", "capsules": "capsule", "vege cap": "capsule",
    "vegicap": "capsule", "vegecaps": "capsule",
    "tablet": "tablet", "tablets": "tablet", "film coated": "tablet",
    "chewable": "tablet", "sublingual": "tablet",
    "soft gel": "soft_gel", "softgel": "soft_gel",
    "liquid": "liquid", "tonic": "liquid", "drop": "liquid", "drops": "liquid",
    "spray": "spray",
    "cream": "cream", "gel": "gel",
    "powder": "powder", "sachet": "powder", "sachets": "powder",
    "lozenge": "lozenge", "lozenges": "lozenge",
}

# -- Pack size patterns: "60 / 120 capsules" or "30 tablets" or "100 mL" --
PACK_SIZE_RE = re.compile(
    r"(\d+(?:\s*/\s*\d+)?(?:\s*-\s*\d+)?)\s*(capsules?|tablets?|soft\s*gels?|mL|ml|"
    r"g(?:ram)?|kg|lozenges?|sachets?|sprays?|drops?|chewable\s*tablets?|"
    r"film[-\s]*coated\s*tablets?|vege\s*caps?)\b",
    re.IGNORECASE,
)

# -- Direction (adult/child) --
ADULT_DIRECTION_RE = re.compile(
    r"adults?\s*[-–—]\s*([^\n]+)", re.IGNORECASE
)
CHILD_DIRECTION_RE = re.compile(
    r"children\s*[-–—]\s*([^\n]+)", re.IGNORECASE
)

# -- "Each X contains:" --
EACH_CONTAINS_RE = re.compile(
    r"each\s+(\d+(?:\.\d+)?\s*\w*\s*\w*)\s+contains:?\s*\n(.*?)(?=\n\n|\n60\s*/|\n30\s*/|\n\d+\s*(?:capsules|tablets|mL|soft gels)|Z\s*$)",
    re.IGNORECASE | re.DOTALL,
)

# -- Ingredient line: "Name (alt name) ............................. 500mg" --
INGREDIENT_LINE_RE = re.compile(
    r"^\s*([A-Z][^.\n]{2,120}?)\s*\.{2,}\s*([\d.,]+\s*[a-zA-Zµ/%]+(?:\s+CFU)?)",
    re.MULTILINE,
)
# Simpler: any text before a dotted leader then a number+unit
INGREDIENT_SIMPLE_RE = re.compile(
    r"^\s*([A-Za-z][^.\n]{2,120}?)\s*\.{2,}\s*([\d.,]+)\s*([a-zA-Zµµ/]+(?:\s*CFU)?)\s*$",
    re.MULTILINE,
)

# -- Severity hint for cautions --
SEVERITY_KEYWORDS = {
    "high": ["contraindicated", "do not", "avoid", "fatal", "life-threatening",
             "not recommended", "should not be used", "must not"],
    "medium": ["caution", "monitor", "use with care", "theoretical", "may increase",
               "may decrease", "limited data", "consult", "advised"],
    "low": ["may cause", "mild", "uncommon", "rare", "generally well tolerated"],
}

# -- Patient group hint extraction --
PATIENT_GROUP_PATTERNS = [
    (r"pregnan", "pregnancy_review_required"),
    (r"breast[\s-]?feed", "breastfeeding_review_required"),
    (r"child(ren)?|paediatric|pediatric|infant", "child_review_required"),
    (r"anticoagul|warfarin|heparin|antiplatelet|aspirin|clopidogrel|apixaban|rivaroxaban|dabigatran|doac",
     "anticoagulant_review_required"),
    (r"renal|kidney", "renal_impairment_caution"),
    (r"liver|hepatic", "liver_impairment_caution"),
    (r"thyroid|levothyroxine", "thyroid_condition_review_required"),
    (r"diabet|insulin|metformin", "diabetes_review_required"),
    (r"hypertens|blood pressure", "hypertension_review_required"),
    (r"autoimmune|immunosuppress", "autoimmune_review_required"),
    (r"immunocompromised|hiv|aids", "immunosuppressed_review_required"),
    (r"seizure|epilep", "seizure_disorder_review_required"),
    (r"surger", "surgery_caution"),
    (r"allerg", "allergy_caution"),
]


def detect_dosage_form(text: str) -> str:
    """Detect dosage form from any text mentioning it (intro/pack size)."""
    t = text.lower()
    if "soft gel" in t:
        return "soft_gel"
    if "chewable" in t and "tablet" in t:
        return "tablet"
    if "vege cap" in t or "vegicap" in t:
        return "capsule"
    if "sublingual" in t and ("tablet" in t or "spray" in t):
        # Use pack size to disambiguate
        m = PACK_SIZE_RE.search(t)
        if m:
            unit = m.group(2).lower()
            if "spray" in unit:
                return "spray"
            return "tablet"
        return "tablet"
    for needle, form in DOSAGE_FORM_MAP.items():
        if needle in t:
            return form
    return "unknown"


def detect_pack_size(text: str) -> str:
    m = PACK_SIZE_RE.search(text)
    if m:
        return f"{m.group(1).strip()} {m.group(2).lower()}"
    return ""


def parse_ingredients(intro_text: str, all_text: str, pdf_page_text: str = "") -> list[dict]:
    """Pull ingredients out of the 'Each X contains:' block.

    Supports several formats found in the manual:
      1. PDF dotted leaders: "Name............500mg"
      2. PDF equiv. leaders: "Compound equiv. element......145.8mg"
      3. Probiotic CFU lines: "Lactobacillus rhamnosus GG  5billion CFU"
      4. Prose description (no strengths) — captured as a placeholder
    """
    ingredients: list[dict] = []

    # First, try to find the "Each X contains:" block
    for source_text in (pdf_page_text, all_text):
        if not source_text:
            continue
        # The block ends at pack size, blank line, or major heading
        m = re.search(
            r"each\s+[\w\s]+\s+contains:?\s*\n(.*?)(?=\n\s*\n|\n\s*\d+\s*/\s*\d+|\n\s*\d+\s+(?:capsules|tablets|mL|soft gels|chewable tablets|spray|lozenges|sachets)|\n\s*DIRECTIONS FOR USE|\n\s*FEATURES|\n\s*TECHNICAL)",
            source_text, re.IGNORECASE | re.DOTALL,
        )
        if not m:
            continue
        block = m.group(1)

        # 1. Dotted-leader lines (PDF format) — incl. "equiv." patterns
        # Captures: name (may contain "equiv. element"), dotted leader, amount, unit
        for line_match in re.finditer(
            r"^\s*([A-Z][^.\n]{2,200}?(?:\s*equiv\.\s*[a-z][^.\n]{0,80}?)?)\s*\.{2,}\s*([\d.,]+)\s*([a-zA-Zµ/%]+(?:\s*CFU)?)\s*$",
            block, re.MULTILINE,
        ):
            raw_name = re.sub(r"\s+", " ", line_match.group(1)).strip(" .,:;")
            amount = line_match.group(2).strip()
            unit = line_match.group(3).strip()
            if len(raw_name) < 3:
                continue
            # Split into name + equivalent if "equiv." present
            equiv_match = re.search(r"^(.+?)\s+equiv\.\s+(.+)$", raw_name, re.IGNORECASE)
            if equiv_match:
                ing_name = equiv_match.group(1).strip()
                equiv_name = equiv_match.group(2).strip()
                ingredients.append({
                    "ingredient_name": ing_name,
                    "ingredient_name_normalised": _norm(ing_name),
                    "ingredient_form": "",
                    "strength": amount,
                    "strength_unit": unit,
                    "equivalent_amount": amount,
                    "equivalent_unit": unit,
                    "equivalent_name": equiv_name,
                    "extraction_confidence": "High" if source_text == pdf_page_text else "Medium",
                })
            else:
                ingredients.append({
                    "ingredient_name": raw_name,
                    "ingredient_name_normalised": _norm(raw_name),
                    "ingredient_form": "",
                    "strength": amount,
                    "strength_unit": unit,
                    "equivalent_amount": "",
                    "equivalent_unit": "",
                    "extraction_confidence": "High" if source_text == pdf_page_text else "Medium",
                })

        # 2. Tab-separated (DOCX format): "Name\t500mg" or "Name  500mg"
        if not ingredients:
            for line_match in re.finditer(
                r"^\s*([A-Z][A-Za-z][^.\n\t]{2,120}?)\s+(?:[\.\t]\s*)?([\d.,]+)\s*([a-zA-Zµ/%]+(?:\s*CFU)?)\s*$",
                block, re.MULTILINE,
            ):
                name = re.sub(r"\s+", " ", line_match.group(1)).strip(" .,:;\t")
                amount = line_match.group(2).strip()
                unit = line_match.group(3).strip()
                if len(name) < 3 or "." in name:
                    continue
                ingredients.append({
                    "ingredient_name": name,
                    "ingredient_name_normalised": _norm(name),
                    "ingredient_form": "",
                    "strength": amount,
                    "strength_unit": unit,
                    "equivalent_amount": "",
                    "equivalent_unit": "",
                    "extraction_confidence": "Medium",
                })

        # 3. CFU lines (probiotics)
        if not ingredients:
            for line_match in re.finditer(
                r"^\s*([A-Z][A-Za-z][^.\n]{2,100}?)\s+(?:[\.\t]\s*)?([\d.,]+)\s*(billion|million|trillion)\s*CFU\s*$",
                block, re.MULTILINE | re.IGNORECASE,
            ):
                name = re.sub(r"\s+", " ", line_match.group(1)).strip(" .,:;\t")
                amount = line_match.group(2).strip()
                unit = "CFU"
                ingredients.append({
                    "ingredient_name": name,
                    "ingredient_name_normalised": _norm(name),
                    "ingredient_form": "",
                    "strength": amount,
                    "strength_unit": unit,
                    "equivalent_amount": "",
                    "equivalent_unit": "",
                    "extraction_confidence": "Medium",
                })

        if ingredients:
            break  # success

    # Deduplicate by normalised name
    seen = {}
    for ing in ingredients:
        k = ing["ingredient_name_normalised"]
        if k and k not in seen:
            seen[k] = ing
    return list(seen.values())


def parse_directions(directions_text: str) -> dict:
    """Parse adult/child dose from DIRECTIONS FOR USE block."""
    adult = ""
    child = ""
    # Strip page-break duplicates: find the half-point where the second
    # half repeats the first
    text = re.sub(r"\n{2,}", "\n", directions_text)
    # Detect duplicate halves
    half = len(text) // 2
    if half > 50:
        first_half = text[:half].strip()
        second_half = text[half:].strip()
        # If second half contains the first half, drop it
        if first_half and (first_half in second_half or second_half in first_half):
            text = first_half
        else:
            # Try a less strict similarity check
            shorter = min(len(first_half), len(second_half))
            if shorter > 30 and first_half[:shorter//2] == second_half[:shorter//2]:
                text = first_half

    a = ADULT_DIRECTION_RE.search(text)
    if a:
        adult = a.group(1).strip()
    c = CHILD_DIRECTION_RE.search(text)
    if c:
        child = c.group(1).strip()
    # If we missed both, take the whole text as the raw direction
    if not adult and not child:
        adult = text.strip()
    return {
        "adult_dose": adult,
        "child_dose": child,
        "raw_text": text.strip(),
    }


def parse_features_and_benefits(text: str) -> list[str]:
    """Split features & benefits block into individual bullet-like statements."""
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.lower() in {"high strength", "low allergy", "vegan friendly"}:
            out.append(line)
        elif len(line) < 80 and not line.endswith("."):
            out.append(line)
    # Dedupe
    seen = set()
    result = []
    for x in out:
        if x.lower() not in seen:
            seen.add(x.lower())
            result.append(x)
    return result


def parse_cautions(cautions_text: str) -> list[dict]:
    """Each bullet in the Cautions block becomes a separate entry."""
    out = []
    # Split on newlines or bullet markers
    bullets = re.split(r"\n\s*•\s*|\n(?=- )|\n(?=\* )", cautions_text)
    for b in bullets:
        b = b.strip(" \n•-")
        if not b or len(b) < 8:
            continue
        # Determine severity
        sev = "medium"
        bl = b.lower()
        for level, words in SEVERITY_KEYWORDS.items():
            if any(w in bl for w in words):
                sev = level
                break
        # Determine caution type
        ctype = "caution"
        if "not recommended" in bl or "contraindicated" in bl or "do not use" in bl or "avoid" in bl:
            ctype = "contraindication"
        if "warning" in bl:
            ctype = "warning"
        if "pregnan" in bl:
            ctype = "pregnancy_breastfeeding"
        if "breast" in bl:
            ctype = "pregnancy_breastfeeding"
        if "child" in bl or "infant" in bl or "paediatric" in bl:
            ctype = "child_use"
        if "allerg" in bl:
            ctype = "allergy"
        # Extract patient group tags
        avoid_tags = []
        for pattern, tag in PATIENT_GROUP_PATTERNS:
            if re.search(pattern, bl):
                avoid_tags.append(tag)
        out.append({
            "caution_text": b,
            "caution_type": ctype,
            "severity": sev,
            "avoid_if_tags": list(set(avoid_tags)),
        })
    # Dedupe by caution text
    seen = set()
    result = []
    for c in out:
        k = c["caution_text"].lower()
        if k not in seen:
            seen.add(k)
            result.append(c)
    return result


def parse_interactions(text: str) -> list[dict]:
    """Each bullet in Drug Interactions block becomes a separate entry."""
    out = []
    bullets = re.split(r"\n\s*•\s*|\n(?=- )|\n(?=\* )", text)
    for b in bullets:
        b = b.strip(" \n•-")
        if not b or len(b) < 8:
            continue
        bl = b.lower()
        # Determine interacting medicine/class
        m_class = ""
        flags = []
        # Common drug class keywords
        if "anticoagulant" in bl or "warfarin" in bl or "heparin" in bl:
            m_class = "anticoagulants"; flags.append("warfarin"); flags.append("anticoagulant")
        if "antiplatelet" in bl or "aspirin" in bl or "clopidogrel" in bl:
            m_class = m_class + ", antiplatelets" if m_class else "antiplatelets"
            flags.append("antiplatelet")
        if "doac" in bl or "apixaban" in bl or "rivaroxaban" in bl or "dabigatran" in bl:
            flags.append("doac")
        if "levothyroxine" in bl or "thyroxine" in bl:
            m_class = m_class + ", levothyroxine" if m_class else "levothyroxine"
            flags.append("levothyroxine")
        if "tetracycline" in bl:
            flags.append("tetracycline_antibiotic")
        if "ciprofloxacin" in bl or "quinolone" in bl or "norfloxacin" in bl:
            flags.append("quinolone_antibiotic")
        if "bisphosphonate" in bl or "alendronate" in bl or "risedronate" in bl:
            flags.append("bisphosphonate")
        if "methotrexate" in bl:
            flags.append("methotrexate")
        if "digoxin" in bl:
            flags.append("digoxin")
        if "antihypertens" in bl:
            flags.append("antihypertensive")
        if "antidiabet" in bl or "insulin" in bl or "metformin" in bl:
            flags.append("antidiabetic")
        if "sedative" in bl or "cns depressant" in bl or "benzodiazepine" in bl:
            flags.append("sedative")
        if "antidepressant" in bl or "ssri" in bl or "maoi" in bl:
            flags.append("antidepressant")
        if "immunosuppress" in bl:
            flags.append("immunosuppressant")
        if "oral contraceptive" in bl or "contraceptive" in bl:
            flags.append("oral_contraceptive")
        if "hormone" in bl and "therapy" in bl:
            flags.append("hormone_therapy")
        if "statin" in bl:
            flags.append("statin")
        if "proton pump" in bl or "ppi" in bl or "omeprazole" in bl:
            flags.append("ppi")
        if "corticosteroid" in bl or "prednisone" in bl or "prednisolone" in bl:
            flags.append("corticosteroid")
        if "diuretic" in bl:
            flags.append("diuretic")
        # Determine action
        if "avoid" in bl or "do not" in bl or "contraindicated" in bl:
            action = "avoid"
        elif "separate" in bl or "2 hours" in bl or "4 hours" in bl:
            action = "separate_dosing"
        elif "monitor" in bl or "caution" in bl or "theoretically" in bl:
            action = "allow_with_counselling"
        else:
            action = "pharmacist_review_required"
        severity = "medium"
        if any(w in bl for w in ["bleed", "fatal", "life-threatening", "serious"]):
            severity = "high"
        elif any(w in bl for w in ["mild", "minor", "minor effect"]):
            severity = "low"
        out.append({
            "interaction_text": b,
            "interacting_medicine_or_class": m_class or "unspecified",
            "medicine_interaction_flags": list(set(flags)),
            "action": action,
            "severity": severity,
        })
    # Dedupe
    seen = set()
    result = []
    for x in out:
        k = x["interaction_text"].lower()
        if k not in seen:
            seen.add(k)
            result.append(x)
    return result


def extract_first_page_intro(section: dict) -> str:
    """The intro paragraph (e.g. 'Herbs of Gold X is a source of ...').

    In the DOCX, this sits BEFORE the first H3 and is captured as raw
    text. Find it in subsections by looking for non-recognised H3 headings.
    """
    # In our extraction, the intro is in the H3 with empty heading OR
    # captured as a 'H3:' entry with heading '' and short text.
    for ss in section.get("subsections", []):
        if ss.get("heading", "").strip() == "":
            return ss.get("text", "").strip()
    return ""


def collect_all_text(section: dict) -> str:
    """Concatenate all subsection text into one blob for fallback parsing."""
    parts = []
    for ss in section.get("subsections", []):
        parts.append(ss.get("text", ""))
    return "\n".join(parts)


def get_subsection(section: dict, name: str) -> str:
    name_u = name.upper().rstrip(":")
    for ss in section.get("subsections", []):
        if ss.get("heading", "").upper().rstrip(":") == name_u:
            return ss.get("text", "").strip()
    return ""


def main():
    sections = json.loads(
        (INTERMEDIATE / "docx_sections.json").read_text(encoding="utf-8")
    )
    toc = json.loads(
        (INTERMEDIATE / "excel_product_pages.json").read_text(encoding="utf-8")
    )
    pdf_pages = json.loads(
        (Path("/Users/hughn78/herbsofgold_scraped/HerbsOfGold_KnowledgeBase/extracted/pdf_pages.json")
         .read_text(encoding="utf-8"))
    )
    page_to_text = {p["page"]: p["text"] for p in pdf_pages}
    pdf_page_index = json.loads(
        (INTERMEDIATE / "pdf_page_index.json").read_text(encoding="utf-8")
    )
    # The TOC page in 'SourcePage' is the manual page; we need to find
    # the actual PDF page for ingredient extraction.
    toc_to_pdf = {}  # norm_name -> first pdf page
    pdf_mp = {int(k): v for k, v in pdf_page_index["page_to_product"].items()}
    # For each manual page, look up the PDF page
    for pdf_p, norm_name in sorted(pdf_mp.items()):
        if norm_name not in toc_to_pdf:
            toc_to_pdf[norm_name] = pdf_p

    products: list[dict] = []
    issues: list[dict] = []
    issue_id = 0

    def add_issue(product_id, product_name, itype, desc, src="docx", page=None, sev="medium", action="Pharmacist review required"):
        nonlocal issue_id
        issue_id += 1
        issues.append({
            "IssueID": f"ISS-{issue_id:04d}",
            "ProductID": product_id,
            "ProductName": product_name,
            "IssueType": itype,
            "IssueDescription": desc,
            "SourceFile": src,
            "SourcePage": page,
            "Severity": sev,
            "SuggestedAction": action,
            "Resolved": False,
        })

    for idx, s in enumerate(sections, start=1):
        pid = make_product_id(idx)
        name = s["product_name"]
        norm = _norm(name)
        page = toc.get(norm)

        # Collect all text
        intro = extract_first_page_intro(s)
        all_text = collect_all_text(s)
        # Use PDF page for ingredient extraction (preserves dotted leaders)
        # The TOC says "page 1" but actual PDF page is offset (typically 4)
        pdf_page_num = toc_to_pdf.get(norm)
        pdf_page_text = page_to_text.get(pdf_page_num, "") if pdf_page_num else ""

        # Each X contains block: usually first paragraphs after "Technical Information"
        # but the intro has "Each capsule contains" lines — search globally
        ingredients = parse_ingredients(intro, all_text, pdf_page_text=pdf_page_text)
        if not ingredients:
            add_issue(pid, name, "missing_ingredient",
                       "No ingredients extracted (no 'Each X contains' block found in DOCX)",
                       page=page, sev="high")

        # Directions
        directions_text = get_subsection(s, "DIRECTIONS FOR USE")
        directions = parse_directions(directions_text)
        if not directions["adult_dose"] and not directions["child_dose"]:
            add_issue(pid, name, "missing_dose",
                       "No adult/child dose direction found in DIRECTIONS FOR USE",
                       page=page, sev="high")

        # Features & Benefits
        fab_text = get_subsection(s, "FEATURES & BENEFITS")
        fabs = parse_features_and_benefits(fab_text)

        # Cautions
        cautions_text = get_subsection(s, "CAUTIONS")
        cautions = parse_cautions(cautions_text)
        if not cautions_text or len(cautions_text.strip()) < 10:
            add_issue(pid, name, "missing_cautions",
                       "No cautions text extracted — assume pharmacist review required before recommending",
                       page=page, sev="medium")

        # Drug interactions
        interactions_text = get_subsection(s, "DRUG INTERACTIONS")
        interactions = parse_interactions(interactions_text)

        # Side effects
        side_effects_text = get_subsection(s, "SIDE EFFECTS")

        # Companion products
        companion_text = get_subsection(s, "COMPANION PRODUCTS")

        # Dosage form + pack size
        # The pack size appears in the PDF as "60 / 120 capsules" or "30 tablets"
        # but my regex was matching "Take 1 capsule" dose lines. Distinguish by
        # checking the line context (not preceded by "Take").
        pack_line = ""
        # Search the PDF first page text (where the pack size is) AND
        # the docx intro, but NOT the all_text which includes directions.
        search_targets = [pdf_page_text, intro]
        for st in search_targets:
            if not st:
                continue
            for ps_re in [
                r"\b\d+\s*/\s*\d+\s+(capsules?|tablets?|soft\s*gels?|lozenges?|sachets?|chewable\s*tablets?|film[-\s]*coated\s*tablets?)\b",
                r"\b\d+\s+(capsules?|tablets?|soft\s*gels?|lozenges?|sachets?|chewable\s*tablets?|film[-\s]*coated\s*tablets?)\s*$",
            ]:
                for m in re.finditer(ps_re, st, re.IGNORECASE | re.MULTILINE):
                    line = m.group(0).strip()
                    start = max(0, m.start() - 30)
                    context = st[start:m.end()].lower()
                    if "take" in context[-30:] or "adults" in context[-30:]:
                        continue
                    pack_line = line
                    break
                if pack_line:
                    break
            if pack_line:
                break
        if not pack_line:
            pack_line = detect_pack_size(intro or all_text[:500])
        # Dosage form needs to search the full text plus the PDF intro
        # (PDF first page has "is a delicious ... liquid" which the DOCX
        # may not have captured in subsections)
        dosage_form = detect_dosage_form(all_text + " " + (pdf_page_text or "")[:2000])
        if dosage_form == "unknown":
            add_issue(pid, name, "missing_dosage_form",
                       "Could not determine dosage form from DOCX text",
                       page=page, sev="low")

        # Indications summary — combine intro + features
        indications_summary = ""
        if intro:
            # Drop the "Each X contains" header from intro
            indications_summary = re.sub(
                r"does not contain.*$", "", intro, flags=re.IGNORECASE | re.DOTALL
            ).strip()
        if not indications_summary and fabs:
            indications_summary = "; ".join(fabs[:6])

        # Pregnancy/breastfeeding summary
        preg_lines = []
        for c in cautions:
            ct = c["caution_text"].lower()
            if "pregnan" in ct or "breast" in ct or "lactat" in ct:
                preg_lines.append(c["caution_text"])
        for s_e in (side_effects_text or "").splitlines():
            if "pregnan" in s_e.lower() or "breast" in s_e.lower():
                preg_lines.append(s_e.strip())
        pregnancy_summary = " | ".join(preg_lines) if preg_lines else ""

        # Indications list — split intro + features into discrete lines
        indications_list: list[dict] = []
        if intro:
            # Drop allergen-free sentence and the "Each X contains" line
            clean = re.sub(r"does not contain.*$", "", intro, flags=re.IGNORECASE | re.DOTALL).strip()
            if clean:
                indications_list.append({
                    "indication_text": clean,
                    "indication_type": "source_label_claim",
                    "clinical_use_tag": "",
                })
        for f in fabs:
            if f and len(f) > 3:
                indications_list.append({
                    "indication_text": f,
                    "indication_type": "nutritional_support",
                    "clinical_use_tag": "",
                })

        # Evidence notes (extract any reference markers like [1], 1, [4] in text)
        ref_count = len(re.findall(r"\[\d+\]|\b\d+\s+[A-Z][a-z]+", all_text))

        # Build product record
        rec = {
            "ProductID": pid,
            "Brand": BRAND,
            "ProductName": name,
            "ProductName_Normalised": norm,
            "AUSTL": "",  # Not in this manual
            "DosageForm": dosage_form,
            "PackSize": pack_line,
            "AdultDose": directions["adult_dose"],
            "ChildDose": directions["child_dose"],
            "Directions": directions["raw_text"],
            "Indications_Summary": indications_summary[:500],
            "Cautions_Summary": " | ".join(c["caution_text"] for c in cautions)[:500],
            "Contraindications_Summary": " | ".join(
                c["caution_text"] for c in cautions
                if c["caution_type"] in {"contraindication", "warning"})[:500],
            "Interactions_Summary": " | ".join(
                i["interaction_text"] for i in interactions)[:500],
            "PregnancyBreastfeeding_Summary": pregnancy_summary,
            "EvidenceNotes": f"~{ref_count} reference markers in DOCX text",
            "ClinicalUseTags": [],   # filled by script 06
            "AvoidIfTags": [],        # filled by script 06
            "MedicineInteractionFlags": [],  # filled by script 06
            "CounsellingPointSummary": "",  # filled by script 06
            "SourceFile_Primary": "herbsofgold_technical_manual.pdf",
            "SourcePage": page if page else "",
            "SourceSection": "Technical Information, Directions, Cautions",
            "ExtractionConfidence": "High" if ingredients and directions["adult_dose"] else "Medium",
            "ReviewStatus": "Unreviewed",
            "ReviewedBy": "",
            "ReviewedDate": "",
            "Notes": "",

            # Internal fields used by later scripts
            "_ingredients": ingredients,
            "_indications_list": indications_list,
            "_cautions_list": cautions,
            "_interactions_list": interactions,
            "_side_effects": side_effects_text.strip(),
            "_companion_products": companion_text.strip(),
            "_features_benefits": fabs,
            "_austl_absent_in_source": True,
        }
        if not ingredients and not directions["adult_dose"]:
            rec["ExtractionConfidence"] = "Low"

        products.append(rec)

    # AUSTL absent in source — record as an issue for ALL products
    for p in products:
        add_issue(p["ProductID"], p["ProductName"], "missing_austl",
                  "AUST L number not present in source manual. This is a known gap. "
                  "Pharmacist must verify AUST L via TGA ARTG search before dispensing.",
                  src="pdf+docx+xlsx", page=p["SourcePage"], sev="medium",
                  action="Look up AUST L via TGA ARTG and update.")

    # Save parsed products
    out_path = INTERMEDIATE / "products_parsed.json"
    out_path.write_text(json.dumps(products, indent=2, ensure_ascii=False), encoding="utf-8")
    log.info("Wrote %s with %d products", out_path, len(products))

    # Save issues
    issues_path = INTERMEDIATE / "extraction_issues_raw.json"
    issues_path.write_text(json.dumps(issues, indent=2, ensure_ascii=False), encoding="utf-8")
    log.info("Wrote %s with %d issues", issues_path, len(issues))

    # Summary
    by_conf = {"High": 0, "Medium": 0, "Low": 0}
    for p in products:
        by_conf[p["ExtractionConfidence"]] = by_conf.get(p["ExtractionConfidence"], 0) + 1
    log.info("Extraction confidence: %s", by_conf)

    with_ings = sum(1 for p in products if p["_ingredients"])
    with_dose = sum(1 for p in products if p["AdultDose"] or p["ChildDose"])
    with_cautions = sum(1 for p in products if p["_cautions_list"])
    log.info("Products with ingredients: %d / %d", with_ings, len(products))
    log.info("Products with dose: %d / %d", with_dose, len(products))
    log.info("Products with cautions: %d / %d", with_cautions, len(products))


if __name__ == "__main__":
    main()
