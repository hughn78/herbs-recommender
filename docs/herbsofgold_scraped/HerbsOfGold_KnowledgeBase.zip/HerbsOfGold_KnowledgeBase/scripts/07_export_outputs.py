#!/usr/bin/env python3
"""07_export_outputs.py — Export the final knowledge base files.

Outputs:
  output/Herbs_of_Gold_Product_Knowledge_Base.xlsx   (12 sheets)
  output/herbs_of_gold_products.csv
  output/herbs_of_gold_products.json
  output/herbs_of_gold_product_chunks.jsonl
"""
from __future__ import annotations
import csv
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import INTERMEDIATE, OUTPUT, get_logger, BRAND

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

log = get_logger("07_export_outputs")

# Header style
HEADER_FONT = Font(bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
WRAP = Alignment(wrap_text=True, vertical="top")


def write_sheet_header(ws, headers):
    for ci, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=ci, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="left")
    # Column widths
    for ci, h in enumerate(headers, 1):
        ws.column_dimensions[get_column_letter(ci)].width = max(12, min(50, len(str(h)) + 2))


def main():
    products = json.loads(
        (INTERMEDIATE / "products_with_tags.json").read_text(encoding="utf-8")
    )
    safety_rules = json.loads(
        (INTERMEDIATE / "safety_rules_draft.json").read_text(encoding="utf-8")
    )
    issues_raw = json.loads(
        (INTERMEDIATE / "extraction_issues_raw.json").read_text(encoding="utf-8")
    )

    log.info("Loaded %d products, %d safety rules, %d issues",
             len(products), len(safety_rules), len(issues_raw))

    OUTPUT.mkdir(parents=True, exist_ok=True)

    # =================================================================
    # 1. Main Excel workbook
    # =================================================================
    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    # --- Sheet A: Products ---
    ws = wb.create_sheet("Products")
    headers = [
        "ProductID", "Brand", "ProductName", "ProductName_Normalised", "AUSTL",
        "DosageForm", "PackSize", "AdultDose", "ChildDose", "Directions",
        "Indications_Summary", "Cautions_Summary", "Contraindications_Summary",
        "Interactions_Summary", "PregnancyBreastfeeding_Summary", "EvidenceNotes",
        "ClinicalUseTags", "AvoidIfTags", "MedicineInteractionFlags",
        "CounsellingPointSummary", "SourceFile_Primary", "SourcePage",
        "SourceSection", "ExtractionConfidence", "ReviewStatus", "ReviewedBy",
        "ReviewedDate", "Notes",
    ]
    write_sheet_header(ws, headers)
    for ri, p in enumerate(products, start=2):
        row = [
            p.get("ProductID", ""),
            p.get("Brand", BRAND),
            p.get("ProductName", ""),
            p.get("ProductName_Normalised", ""),
            p.get("AUSTL", ""),
            p.get("DosageForm", ""),
            p.get("PackSize", ""),
            p.get("AdultDose", ""),
            p.get("ChildDose", ""),
            p.get("Directions", ""),
            p.get("Indications_Summary", ""),
            p.get("Cautions_Summary", ""),
            p.get("Contraindications_Summary", ""),
            p.get("Interactions_Summary", ""),
            p.get("PregnancyBreastfeeding_Summary", ""),
            p.get("EvidenceNotes", ""),
            ", ".join(p.get("ClinicalUseTags", [])),
            ", ".join(p.get("AvoidIfTags", [])),
            ", ".join(p.get("MedicineInteractionFlags", [])),
            p.get("CounsellingPointSummary", ""),
            p.get("SourceFile_Primary", "herbsofgold_technical_manual.pdf"),
            p.get("SourcePage", ""),
            p.get("SourceSection", ""),
            p.get("ExtractionConfidence", "Medium"),
            p.get("ReviewStatus", "Unreviewed"),
            p.get("ReviewedBy", ""),
            p.get("ReviewedDate", ""),
            p.get("Notes", ""),
        ]
        for ci, v in enumerate(row, 1):
            cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
            cell.alignment = WRAP
    # Freeze header
    ws.freeze_panes = "A2"
    log.info("Wrote Products sheet: %d rows", len(products))

    # --- Sheet B: Ingredients ---
    ws = wb.create_sheet("Ingredients")
    headers = ["IngredientID", "IngredientName", "IngredientName_Normalised",
               "IngredientType", "Notes"]
    write_sheet_header(ws, headers)
    # Build unique ingredient list
    ing_index: dict[str, dict] = {}
    ing_id = 0
    for p in products:
        for ing in p.get("_ingredients", []):
            norm = ing.get("ingredient_name_normalised", "")
            if norm and norm not in ing_index:
                ing_id += 1
                ing_index[norm] = {
                    "IngredientID": f"ING-{ing_id:04d}",
                    "IngredientName": ing.get("ingredient_name", ""),
                    "IngredientName_Normalised": norm,
                    "IngredientType": classify_local(ing.get("ingredient_name", "")),
                    "Notes": "",
                }
    for ri, ing in enumerate(ing_index.values(), start=2):
        for ci, h in enumerate(headers, 1):
            cell = ws.cell(row=ri, column=ci, value=ing.get(h, ""))
            cell.alignment = WRAP
    ws.freeze_panes = "A2"
    log.info("Wrote Ingredients sheet: %d unique ingredients", len(ing_index))

    # --- Sheet C: Product_Ingredients ---
    ws = wb.create_sheet("Product_Ingredients")
    headers = ["ProductID", "ProductName", "IngredientID", "IngredientName",
               "IngredientForm", "Strength", "StrengthUnit",
               "EquivalentAmount", "EquivalentUnit", "PerDoseOrPerUnit",
               "Notes", "SourcePage", "ExtractionConfidence"]
    write_sheet_header(ws, headers)
    ri = 2
    for p in products:
        for ing in p.get("_ingredients", []):
            norm = ing.get("ingredient_name_normalised", "")
            row = [
                p["ProductID"], p["ProductName"],
                ing_index.get(norm, {}).get("IngredientID", ""),
                ing.get("ingredient_name", ""),
                ing.get("ingredient_form", ""),
                ing.get("strength", ""),
                ing.get("strength_unit", ""),
                ing.get("equivalent_amount", ""),
                ing.get("equivalent_unit", ""),
                "",  # PerDoseOrPerUnit
                ing.get("equivalent_name", ""),
                p.get("SourcePage", ""),
                ing.get("extraction_confidence", ""),
            ]
            for ci, v in enumerate(row, 1):
                cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
                cell.alignment = WRAP
            ri += 1
    ws.freeze_panes = "A2"
    log.info("Wrote Product_Ingredients sheet")

    # --- Sheet D: Indications ---
    ws = wb.create_sheet("Indications")
    headers = ["ProductID", "ProductName", "IndicationText", "IndicationType",
               "ClinicalUseTag", "SourcePage", "SourceSection", "ExtractionConfidence"]
    write_sheet_header(ws, headers)
    ri = 2
    for p in products:
        for ind in p.get("_indications_list", []):
            row = [
                p["ProductID"], p["ProductName"],
                ind.get("indication_text", ""),
                ind.get("indication_type", ""),
                ind.get("clinical_use_tag", ""),
                p.get("SourcePage", ""),
                "Technical Information / Features & Benefits",
                p.get("ExtractionConfidence", ""),
            ]
            for ci, v in enumerate(row, 1):
                cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
                cell.alignment = WRAP
            ri += 1
    ws.freeze_panes = "A2"
    log.info("Wrote Indications sheet")

    # --- Sheet E: Cautions_Contraindications ---
    ws = wb.create_sheet("Cautions_Contraindications")
    headers = ["ProductID", "ProductName", "CautionText", "CautionType", "Severity",
               "AvoidIfTag", "SourcePage", "SourceSection", "ExtractionConfidence"]
    write_sheet_header(ws, headers)
    ri = 2
    for p in products:
        for c in p.get("_cautions_list", []):
            tags = ", ".join(c.get("avoid_if_tags", []))
            row = [
                p["ProductID"], p["ProductName"],
                c.get("caution_text", ""),
                c.get("caution_type", ""),
                c.get("severity", ""),
                tags,
                p.get("SourcePage", ""),
                "Cautions",
                p.get("ExtractionConfidence", ""),
            ]
            for ci, v in enumerate(row, 1):
                cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
                cell.alignment = WRAP
            ri += 1
    ws.freeze_panes = "A2"
    log.info("Wrote Cautions sheet")

    # --- Sheet F: Interactions ---
    ws = wb.create_sheet("Interactions")
    headers = ["ProductID", "ProductName", "IngredientName", "InteractingMedicineOrClass",
               "InteractionText", "Action", "Severity", "MedicineInteractionFlag",
               "SourcePage", "SourceSection", "ExtractionConfidence"]
    write_sheet_header(ws, headers)
    ri = 2
    for p in products:
        for i in p.get("_interactions_list", []):
            # First ingredient (best guess) — we don't link specific interactions
            # to specific ingredients in our extraction, so use the product's
            # first ingredient as a marker.
            first_ing = ""
            if p.get("_ingredients"):
                first_ing = p["_ingredients"][0].get("ingredient_name", "")
            flags = ", ".join(i.get("medicine_interaction_flags", []))
            row = [
                p["ProductID"], p["ProductName"], first_ing,
                i.get("interacting_medicine_or_class", ""),
                i.get("interaction_text", ""),
                i.get("action", ""),
                i.get("severity", ""),
                flags,
                p.get("SourcePage", ""),
                "Drug Interactions",
                p.get("ExtractionConfidence", ""),
            ]
            for ci, v in enumerate(row, 1):
                cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
                cell.alignment = WRAP
            ri += 1
    ws.freeze_panes = "A2"
    log.info("Wrote Interactions sheet")

    # --- Sheet G: Clinical_Tags ---
    ws = wb.create_sheet("Clinical_Tags")
    headers = ["ProductID", "ProductName", "TagType", "Tag", "Reason",
               "SourcePage", "RequiresPharmacistReview"]
    write_sheet_header(ws, headers)
    ri = 2
    for p in products:
        tags = p.get("_tags_cache", {})
        all_tags = tags.get("clinical_use_tags", []) + tags.get("avoid_if_tags", [])
        for t in all_tags:
            row = [
                p["ProductID"], p["ProductName"],
                t.get("TagType", ""), t.get("Tag", ""),
                t.get("Reason", ""),
                p.get("SourcePage", ""),
                "TRUE" if t.get("RequiresPharmacistReview") else "FALSE",
            ]
            for ci, v in enumerate(row, 1):
                cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
                cell.alignment = WRAP
            ri += 1
        # Add medicine interaction flags
        for flag in tags.get("medicine_interaction_flags", []):
            row = [
                p["ProductID"], p["ProductName"],
                "medicine_trigger", flag,
                "Medicine interaction flag (auto-derived from ingredient pattern)",
                p.get("SourcePage", ""),
                "TRUE",
            ]
            for ci, v in enumerate(row, 1):
                cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
                cell.alignment = WRAP
            ri += 1
    ws.freeze_panes = "A2"
    log.info("Wrote Clinical_Tags sheet")

    # --- Sheet H: Counselling_Points ---
    ws = wb.create_sheet("Counselling_Points")
    headers = ["ProductID", "ProductName", "CounsellingPoint", "CounsellingType",
               "PharmacistOnly", "PatientFriendlyVersion", "SourcePage",
               "SourceSection", "ExtractionConfidence"]
    write_sheet_header(ws, headers)
    ri = 2
    for p in products:
        for c in p.get("_counselling_points", []):
            row = [
                p["ProductID"], p["ProductName"],
                c.get("pharmacist_point", ""),
                c.get("counselling_type", ""),
                "TRUE",  # all our points are pharmacist-only by default
                c.get("patient_friendly_version", ""),
                c.get("source_page", ""),
                "Generated from source text + ingredient pattern",
                c.get("extraction_confidence", ""),
            ]
            for ci, v in enumerate(row, 1):
                cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
                cell.alignment = WRAP
            ri += 1
    ws.freeze_panes = "A2"
    log.info("Wrote Counselling_Points sheet")

    # --- Sheet I: Safety_Rules_Draft ---
    ws = wb.create_sheet("Safety_Rules_Draft")
    headers = ["RuleID", "RuleName", "TriggerMedication", "TriggerDrugClass",
               "TriggerPatientFactor", "TriggerIngredient", "TriggerProductTag",
               "Action", "Severity", "PharmacistMessage", "PatientTalkingPoint",
               "SourceBasis", "RequiresPharmacistReview"]
    write_sheet_header(ws, headers)
    ri = 2
    for r in safety_rules:
        row = [r.get(h, "") for h in headers]
        for ci, v in enumerate(row, 1):
            cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
            cell.alignment = WRAP
        ri += 1
    ws.freeze_panes = "A2"
    log.info("Wrote Safety_Rules_Draft sheet: %d rules", len(safety_rules))

    # --- Sheet J: Source_References ---
    ws = wb.create_sheet("Source_References")
    headers = ["SourceReferenceID", "ProductID", "ProductName", "SourceFile",
               "SourcePage", "SourceSection", "ExtractedText", "ExtractionMethod", "Notes"]
    write_sheet_header(ws, headers)
    sref_id = 0
    for p in products:
        sref_id += 1
        page = p.get("SourcePage", "")
        # First reference: from PDF/DOCX
        text_excerpt = (p.get("Indications_Summary", "") or "")[:500]
        row = [
            f"SREF-{sref_id:04d}",
            p["ProductID"], p["ProductName"],
            "herbsofgold_technical_manual.pdf",
            page,
            "Technical Information",
            text_excerpt,
            "PyMuPDF text extraction + python-docx structured read",
            "Primary product section",
        ]
        for ci, v in enumerate(row, 1):
            cell = ws.cell(row=sref_id + 1, column=ci, value=str(v) if v is not None else "")
            cell.alignment = WRAP
    ws.freeze_panes = "A2"
    log.info("Wrote Source_References sheet: %d references", sref_id)

    # --- Sheet K: Review_Log (empty starter) ---
    ws = wb.create_sheet("Review_Log")
    headers = ["ReviewID", "ProductID", "ProductName", "FieldReviewed",
               "PreviousValue", "NewValue", "ReviewedBy", "ReviewedDate",
               "ReviewOutcome", "Notes"]
    write_sheet_header(ws, headers)
    # Add a placeholder row
    row = ["REV-0001", "", "", "ReviewStatus", "Unreviewed", "", "",
           "", "Template row — see Review_Log for usage", "Use this sheet to log manual pharmacist reviews"]
    for ci, v in enumerate(row, 1):
        cell = ws.cell(row=2, column=ci, value=v)
        cell.alignment = WRAP
    ws.freeze_panes = "A2"
    log.info("Wrote Review_Log sheet (template)")

    # --- Sheet L: Extraction_Issues ---
    ws = wb.create_sheet("Extraction_Issues")
    headers = ["IssueID", "ProductID", "ProductName", "IssueType", "IssueDescription",
               "SourceFile", "SourcePage", "Severity", "SuggestedAction", "Resolved"]
    write_sheet_header(ws, headers)
    for ri, iss in enumerate(issues_raw, start=2):
        row = [iss.get(h, "") for h in headers]
        for ci, v in enumerate(row, 1):
            cell = ws.cell(row=ri, column=ci, value=str(v) if v is not None else "")
            cell.alignment = WRAP
    ws.freeze_panes = "A2"
    log.info("Wrote Extraction_Issues sheet: %d issues", len(issues_raw))

    # Save main workbook
    main_xlsx = OUTPUT / "Herbs_of_Gold_Product_Knowledge_Base.xlsx"
    wb.save(str(main_xlsx))
    log.info("Saved main workbook: %s", main_xlsx)

    # =================================================================
    # 2. CSV (flat product-level)
    # =================================================================
    csv_path = OUTPUT / "herbs_of_gold_products.csv"
    csv_headers = [
        "ProductID", "Brand", "ProductName", "ProductName_Normalised", "AUSTL",
        "DosageForm", "PackSize", "AdultDose", "ChildDose", "Directions",
        "Indications_Summary", "Cautions_Summary", "Contraindications_Summary",
        "Interactions_Summary", "PregnancyBreastfeeding_Summary", "EvidenceNotes",
        "ClinicalUseTags", "AvoidIfTags", "MedicineInteractionFlags",
        "CounsellingPointSummary", "SourceFile_Primary", "SourcePage",
        "SourceSection", "ExtractionConfidence", "ReviewStatus", "Notes",
    ]
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(csv_headers)
        for p in products:
            row = [
                p.get("ProductID", ""),
                p.get("Brand", BRAND),
                p.get("ProductName", ""),
                p.get("ProductName_Normalised", ""),
                p.get("AUSTL", ""),
                p.get("DosageForm", ""),
                p.get("PackSize", ""),
                p.get("AdultDose", ""),
                p.get("ChildDose", ""),
                p.get("Directions", ""),
                p.get("Indications_Summary", ""),
                p.get("Cautions_Summary", ""),
                p.get("Contraindications_Summary", ""),
                p.get("Interactions_Summary", ""),
                p.get("PregnancyBreastfeeding_Summary", ""),
                p.get("EvidenceNotes", ""),
                ", ".join(p.get("ClinicalUseTags", [])),
                ", ".join(p.get("AvoidIfTags", [])),
                ", ".join(p.get("MedicineInteractionFlags", [])),
                p.get("CounsellingPointSummary", ""),
                p.get("SourceFile_Primary", ""),
                p.get("SourcePage", ""),
                p.get("SourceSection", ""),
                p.get("ExtractionConfidence", ""),
                p.get("ReviewStatus", "Unreviewed"),
                p.get("Notes", ""),
            ]
            w.writerow(row)
    log.info("Wrote CSV: %s", csv_path)

    # =================================================================
    # 3. JSON (structured product-level)
    # =================================================================
    json_path = OUTPUT / "herbs_of_gold_products.json"
    products_json = []
    for p in products:
        rec = {
            "product_id": p.get("ProductID", ""),
            "brand": p.get("Brand", BRAND),
            "product_name": p.get("ProductName", ""),
            "product_name_normalised": p.get("ProductName_Normalised", ""),
            "austl": p.get("AUSTL", ""),
            "dosage_form": p.get("DosageForm", ""),
            "pack_size": p.get("PackSize", ""),
            "directions": {
                "adult_dose": p.get("AdultDose", ""),
                "child_dose": p.get("ChildDose", ""),
                "raw_text": p.get("Directions", ""),
            },
            "ingredients": [
                {
                    "ingredient_name": i.get("ingredient_name", ""),
                    "ingredient_form": i.get("ingredient_form", ""),
                    "strength": i.get("strength", ""),
                    "strength_unit": i.get("strength_unit", ""),
                    "equivalent_amount": i.get("equivalent_amount", ""),
                    "equivalent_unit": i.get("equivalent_unit", ""),
                    "equivalent_name": i.get("equivalent_name", ""),
                    "source_page": p.get("SourcePage", ""),
                    "extraction_confidence": i.get("extraction_confidence", ""),
                }
                for i in p.get("_ingredients", [])
            ],
            "indications": [
                {
                    "text": ind.get("indication_text", ""),
                    "type": ind.get("indication_type", ""),
                    "clinical_use_tag": ind.get("clinical_use_tag", ""),
                    "source_page": p.get("SourcePage", ""),
                }
                for ind in p.get("_indications_list", [])
            ],
            "cautions": [
                {
                    "text": c.get("caution_text", ""),
                    "type": c.get("caution_type", ""),
                    "severity": c.get("severity", ""),
                    "avoid_if_tag": ", ".join(c.get("avoid_if_tags", [])),
                    "source_page": p.get("SourcePage", ""),
                }
                for c in p.get("_cautions_list", [])
            ],
            "interactions": [
                {
                    "ingredient_name": (p["_ingredients"][0]["ingredient_name"]
                                        if p.get("_ingredients") else ""),
                    "interacting_medicine_or_class": i.get("interacting_medicine_or_class", ""),
                    "interaction_text": i.get("interaction_text", ""),
                    "action": i.get("action", ""),
                    "severity": i.get("severity", ""),
                    "medicine_interaction_flag": ", ".join(i.get("medicine_interaction_flags", [])),
                    "source_page": p.get("SourcePage", ""),
                }
                for i in p.get("_interactions_list", [])
            ],
            "clinical_tags": {
                "clinical_use_tags": p.get("ClinicalUseTags", []),
                "avoid_if_tags": p.get("AvoidIfTags", []),
                "medicine_interaction_flags": p.get("MedicineInteractionFlags", []),
                "counselling_flags": [],
            },
            "counselling_points": p.get("_counselling_points", []),
            "source_references": [
                {
                    "source_file": "herbsofgold_technical_manual.pdf",
                    "source_page": p.get("SourcePage", ""),
                    "source_section": "Technical Information / Cautions / Drug Interactions",
                    "extracted_text": (p.get("Indications_Summary", "") or "")[:500],
                }
            ],
            "review": {
                "review_status": p.get("ReviewStatus", "Unreviewed"),
                "reviewed_by": p.get("ReviewedBy", ""),
                "reviewed_date": p.get("ReviewedDate", ""),
                "notes": p.get("Notes", ""),
            },
        }
        products_json.append(rec)

    json_path.write_text(
        json.dumps(products_json, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Wrote JSON: %s", json_path)

    # =================================================================
    # 4. JSONL chunks (for RAG / vector DB ingestion)
    # =================================================================
    jsonl_path = OUTPUT / "herbs_of_gold_product_chunks.jsonl"
    chunk_count = 0
    with jsonl_path.open("w", encoding="utf-8") as fh:
        for p in products:
            pid = p["ProductID"]
            pname = p["ProductName"]
            sp = p.get("SourcePage", "")
            tags = p.get("_tags_cache", {})
            cu = p.get("ClinicalUseTags", [])
            mf = p.get("MedicineInteractionFlags", [])
            base_meta = {
                "brand": BRAND,
                "austl": p.get("AUSTL", ""),
                "clinical_tags": cu,
                "medicine_interaction_flags": mf,
                "dosage_form": p.get("DosageForm", ""),
            }
            # Chunks per section
            chunks = [
                ("overview",
                 f"Herbs of Gold {pname}. "
                 f"Dosage form: {p.get('DosageForm','unknown')}. "
                 f"Pack size: {p.get('PackSize','')}. "
                 f"Indication: {p.get('Indications_Summary','')[:300]}",
                 "Product overview"),
                ("ingredients",
                 f"Active ingredients in Herbs of Gold {pname}: "
                 + "; ".join(
                     f"{i.get('ingredient_name','')} {i.get('strength','')}{i.get('strength_unit','')}"
                     for i in p.get("_ingredients", [])
                 ) if p.get("_ingredients") else f"No specific ingredients with strengths listed in source for {pname}.",
                 "Each X contains"),
                ("directions",
                 f"Directions for Herbs of Gold {pname}: "
                 f"Adult: {p.get('AdultDose','')[:300]}. "
                 f"Child: {p.get('ChildDose','')[:200] or 'Not specified in source.'}",
                 "Directions for use"),
                ("indications",
                 "; ".join(ind.get("indication_text", "") for ind in p.get("_indications_list", []))[:500]
                 or p.get("Indications_Summary", "")[:500],
                 "Features & benefits / Technical information"),
                ("cautions",
                 "; ".join(c.get("caution_text", "") for c in p.get("_cautions_list", []))[:600]
                 or "No cautions extracted from source. Pharmacist review required.",
                 "Cautions"),
                ("interactions",
                 "; ".join(i.get("interaction_text", "") for i in p.get("_interactions_list", []))[:600]
                 or "No specific drug interactions listed in source.",
                 "Drug interactions"),
                ("side_effects",
                 (p.get("_side_effects", "") or "Not specified.")[:500],
                 "Side effects"),
                ("counselling",
                 " | ".join(c.get("pharmacist_point", "") for c in p.get("_counselling_points", []))[:800],
                 "Pharmacist counselling points (generated)"),
            ]
            for idx, (section, text, src_section) in enumerate(chunks, start=1):
                if not text.strip():
                    continue
                chunk_id = f"{pid}-{section}-{idx:03d}"
                rec = {
                    "chunk_id": chunk_id,
                    "product_id": pid,
                    "product_name": pname,
                    "section": section,
                    "text": text,
                    "source_file": "herbsofgold_technical_manual.pdf",
                    "source_page": sp,
                    "source_section": src_section,
                    "metadata": base_meta,
                }
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
                chunk_count += 1
    log.info("Wrote JSONL: %s (%d chunks)", jsonl_path, chunk_count)


def classify_local(name: str) -> str:
    """Light ingredient classifier for the Ingredients sheet (avoids circular import)."""
    import re
    n = name.lower()
    if re.search(r"\bvitamin\s+[abcdke]|\bfolate|\bfolic\s+acid|\bniacin|\bbiotin|\bthiamine|\briboflavin|\bcobalamin|\bpyridoxine|\bcholecalciferol|\bmenaquinone|\btocopherol|\bcalcitriol|\bcarotene|\bretinol", n):
        return "vitamin"
    if re.search(r"\bmagnesium|\bcalcium|\biron|\bzinc|\bselenium|\bchromium|\bmanganese|\bpotassium|\bsodium|\bcopper|\biodine|\bmolybdenum|\bboron|\bsilicon", n):
        return "mineral"
    if re.search(r"\bcarnitine|\btyrosine|\btaurine|\blysine|\barginine|\bmethionine|\bcysteine|\bglutamine|\btryptophan|\bphenylalanine|\bglycine|\btheanine|\bhistidine", n):
        return "amino_acid"
    if re.search(r"\blactobacillus|\bbifidobacterium|\bsaccharomyces|\bprobiotic|\bcfu", n):
        return "probiotic"
    if re.search(r"\bamylase|\blipase|\bprotease|\bbromelain|\bpepsin|\btrypsin|\bpapain|\bcellulase|\blactase|\benzyme", n):
        return "enzyme"
    if re.search(r"\bomega[\s-]*3|\bepa|\bdha|\bfish\s+oil|\bflaxseed|\bevening\s+primrose|\bsea\s+buckthorn|\bborage", n):
        return "oil"
    if re.search(r"\bextract|\bherb|\broot|\bleaf|\bbark|\bflower|\brhizome|\bfruit|\bseed|\bginkgo|\bechinacea|st[\s.]*john|\bvalerian|\bginseng|\bbrahmi|\bbacopa|\bsaw\s+palmetto|\bsilymarin|\bmilk\s+thistle|\bchamomile|\bskullcap|\boats|\bpassionflower|\blemon\s+balm|\bhawthorn|\bblack\s+cohosh|\bvitex|\bsage|\brosemary|\bthyme|\bgarlic|\bturmeric|\bginger|\bfenugreek|\bhops|\bgriffonia|\bsaffron|\breishi|\bchaga|\blion's\s+mane|\bcordyceps|\bmaitake|\bshiitake|\btribulus|\bwithania|\basiwagandha|\bamla|\bgoji|\bacai|\bnoni|\bastragalus|\belderberry|\bberry|\bpeppermint|\bspearmint|\bfennel|\bdandelion|\bnettle|\bhorse\s+chestnut|\bcelery\s+seed|\bdevil's\s+claw|\bglucomannan|\bslippery\s+elm|\bcurcumin", n):
        return "herb"
    return "other"


if __name__ == "__main__":
    main()
