#!/usr/bin/env python3
"""02_extract_excel.py — Extract raw sheet data from the Herbs of Gold XLSX.

The XLSX is a flattened export of the manual (1 sheet 'Table 1', 1422x67).
This script:
  - Dumps every sheet to extracted/excel_sheets/<sheet>.csv
  - Records a structure summary in intermediate/excel_structure_summary.json
  - Identifies candidate ingredient-table regions for cross-validation
"""
from __future__ import annotations
import csv
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import SRC, EXTRACTED, INTERMEDIATE, get_logger

import openpyxl

log = get_logger("02_extract_excel")


def main():
    log.info("Opening XLSX: %s", SRC["xlsx"])
    wb = openpyxl.load_workbook(str(SRC["xlsx"]), data_only=True, read_only=False)
    summary = {"sheets": []}
    out_dir = EXTRACTED / "excel_sheets"
    out_dir.mkdir(parents=True, exist_ok=True)

    for name in wb.sheetnames:
        ws = wb[name]
        rows = list(ws.iter_rows(values_only=True))
        n_rows = len(rows)
        n_cols = max((len(r) for r in rows), default=0)
        log.info("Sheet %r: %d rows x %d cols", name, n_rows, n_cols)

        # Write CSV
        safe_name = name.replace("/", "_").replace(" ", "_")
        csv_path = out_dir / f"{safe_name}.csv"
        with csv_path.open("w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            for r in rows:
                w.writerow(["" if c is None else str(c).replace("\n", " ⏎ ") for c in r])

        # Try to find product-list region (single column of product names)
        product_column = None
        if n_rows > 0:
            # Heuristic: first non-empty column that has many short string cells
            for ci in range(min(n_cols, 5)):
                vals = [rows[i][ci] for i in range(min(200, n_rows)) if rows[i][ci] is not None]
                if len(vals) > 30 and all(isinstance(v, str) and len(v) < 80 for v in vals):
                    product_column = ci
                    break

        summary["sheets"].append({
            "name": name,
            "rows": n_rows,
            "cols": n_cols,
            "csv_path": str(csv_path.relative_to(EXTRACTED.parent)),
            "product_column": product_column,
        })

    (INTERMEDIATE / "excel_structure_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    log.info("Wrote structure summary: %d sheets", len(summary["sheets"]))

    # Quick spot-check: pull first 30 product names if found
    if summary["sheets"] and summary["sheets"][0]["product_column"] is not None:
        ci = summary["sheets"][0]["product_column"]
        ws0 = wb[wb.sheetnames[0]]
        sample = []
        for row in ws0.iter_rows(values_only=True):
            v = row[ci] if ci < len(row) else None
            if isinstance(v, str) and v.strip() and v not in sample:
                sample.append(v.strip())
            if len(sample) >= 50:
                break
        (INTERMEDIATE / "excel_product_sample.json").write_text(
            json.dumps(sample, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        log.info("Wrote sample of %d product-like cells (col %d)", len(sample), ci)


if __name__ == "__main__":
    main()
