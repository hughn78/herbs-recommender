#!/usr/bin/env python3
"""03_extract_pdf.py — Extract text from the PDF page by page.

Outputs:
  extracted/pdf_pages.json       — list of {page, text} for all 206 pages
  intermediate/pdf_page_index.json — page -> product (best-effort mapping
                                     using TOC page numbers from XLSX)
"""
from __future__ import annotations
import json
import sys
import re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import SRC, EXTRACTED, INTERMEDIATE, get_logger, normalise_name

import pymupdf

log = get_logger("03_extract_pdf")


def main():
    log.info("Opening PDF: %s", SRC["pdf"])
    doc = pymupdf.open(str(SRC["pdf"]))
    n_pages = doc.page_count
    log.info("Pages: %d | metadata: %s", n_pages, doc.metadata)

    pages: list[dict] = []
    for i in range(n_pages):
        page = doc.load_page(i)
        text = page.get_text("text")
        # Find all "PRODUCT" and large headings on this page
        # The footer of each page says "X | Herbs of Gold Technical Manual"
        pages.append({
            "page": i + 1,
            "text": text,
            "char_count": len(text),
        })

    (EXTRACTED / "pdf_pages.json").write_text(
        json.dumps(pages, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Wrote pdf_pages.json: %d pages", len(pages))

    # Load TOC
    toc_path = INTERMEDIATE / "excel_product_pages.json"
    if toc_path.exists():
        toc = json.loads(toc_path.read_text(encoding="utf-8"))
    else:
        toc = {}

    # Build a per-page index of which product is dominant
    # The PDF has 3 front-matter pages (cover, blank/inside, TOC) so the
    # manual page 1 is at PDF page 4. The offset is determined dynamically
    # by finding the first PDF page that contains 'TECHNICAL INFORMATION'
    # (which is the start of the first product section).
    offset = 0
    for p in pages[:10]:
        if "TECHNICAL INFORMATION" in p["text"] and "Acetyl" in p["text"]:
            offset = p["page"] - 1  # manual page 1 -> PDF page offset+1
            break
    if offset == 0:
        offset = 3  # known default for this manual
    log.info("TOC -> PDF page offset: %d", offset)

    page_index: dict[int, str] = {}
    sorted_toc = sorted(toc.items(), key=lambda x: x[1])
    for idx, (norm_name, manual_page) in enumerate(sorted_toc):
        start = manual_page + offset
        if idx + 1 < len(sorted_toc):
            end = sorted_toc[idx + 1][1] + offset - 1
        else:
            end = n_pages
        for p in range(start, min(end, n_pages) + 1):
            page_index[p] = norm_name

    (INTERMEDIATE / "pdf_page_index.json").write_text(
        json.dumps({"page_to_product": {str(k): v for k, v in page_index.items()},
                    "toc": toc}, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Wrote pdf_page_index.json: %d pages mapped to products", len(page_index))

    # Stats
    empty_pages = [p["page"] for p in pages if p["char_count"] < 50]
    log.info("Empty/sparse pages (<50 chars): %d (%s)", len(empty_pages),
             empty_pages[:10])

    # Verify a few product pages exist
    sample = ["Acetyl L-Carnitine", "Vitamin D3 1000", "Magnesium Forte"]
    for name in sample:
        target = normalise_name(name)
        if target in toc:
            pn = toc[target]
            txt = pages[pn - 1]["text"][:200] if pn <= len(pages) else ""
            log.info("Sample %s -> page %d: %s", name, pn, txt[:80].replace("\n", " | "))


if __name__ == "__main__":
    main()
