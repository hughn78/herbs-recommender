#!/usr/bin/env python3
"""06_generate_tags.py — Generate ClinicalUseTags, AvoidIfTags,
MedicineInteractionFlags, CounsellingPoints, and draft SafetyRules.

Rules:
  - Tags must be conservative and explainable.
  - Tags are tied to ingredients, source indications, or source cautions.
  - Inferred tags (not explicitly stated) are flagged RequiresPharmacistReview.
  - No disease treatment claims, no patient-facing advice as final.
"""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import (
    INTERMEDIATE, OUTPUT, get_logger, normalise_name, classify_ingredient,
)

log = get_logger("06_generate_tags")

# --- Tag rule definitions ---
# Each rule maps a normalized ingredient or text pattern to a list of
# (TagType, Tag, Reason, RequiresPharmacistReview) entries.

# Clinical use tags by ingredient
CLINICAL_USE_RULES: list[tuple[str, str, str, bool]] = [
    # (ingredient pattern, tag, reason, requires_review)
    (r"\bmagnesium\b", "magnesium_support", "Contains magnesium", False),
    (r"\bmagnesium\b", "muscle_cramps", "Magnesium supports muscle function", False),
    (r"\bmagnesium\b", "sleep_support", "Magnesium may support sleep (per source)", True),
    (r"\bmagnesium\b", "stress_support", "Magnesium involved in nervous system function", True),
    (r"\bmagnesium\b", "nervous_system_support", "Magnesium supports nervous system", False),
    (r"\bcalcium\b", "calcium_support", "Contains calcium", False),
    (r"\bcalcium\b", "bone_health", "Calcium supports bone health", False),
    (r"\bcolecalciferol|\bcholecalciferol|\bvitamin\s*d\s*3|\bvitamin\s*d3", "vitamin_d_support", "Contains vitamin D3", False),
    (r"\bcolecalciferol|\bcholecalciferol|\bvitamin\s*d\s*3|\bvitamin\s*d3", "bone_health", "Vitamin D supports bone health", False),
    (r"\bmenaquinone|\bvitamin\s*k\s*2|\bvitamin\s*k2", "bone_health", "Vitamin K2 supports bone health", False),
    (r"\biron\b", "iron_support", "Contains iron", False),
    (r"\biron\b", "energy_support", "Iron supports energy production", False),
    (r"\bmethylcobalamin|\bcyanocobalamin|\bvitamin\s*b\s*12|\bvitamin\s*b12|\bcobalamin", "b12_support", "Contains vitamin B12", False),
    (r"\bmethylcobalamin|\bcyanocobalamin|\bvitamin\s*b\s*12|\bvitamin\s*b12|\bcobalamin", "energy_support", "Vitamin B12 supports energy", False),
    (r"\bmethylcobalamin|\bcyanocobalamin|\bvitamin\s*b\s*12|\bvitamin\s*b12|\bcobalamin", "nervous_system_support", "Vitamin B12 supports nervous system", False),
    (r"\bmethylfolate|\bfolic\s*acid|\bfolate", "folate_support", "Contains folate", False),
    (r"\bmethylfolate|\bfolic\s*acid|\bfolate", "pregnancy_support", "Folate important in pregnancy (per source)", False),
    (r"\bzinc\b", "immune_support", "Zinc supports immune function", True),
    (r"\bzinc\b", "skin_health", "Zinc supports skin health", True),
    (r"\bzinc\b", "hair_nail_support", "Zinc supports hair/nail health", True),
    (r"\bselenium\b", "antioxidant_support", "Selenium is an antioxidant", True),
    (r"\bchromium\b", "general_multivitamin", "Contains chromium (mineral)", True),
    (r"\biode\b|\bpotassium\s*iodide", "general_multivitamin", "Contains iodine", True),
    (r"\bvitamin\s*c\s*|ascorb", "immune_support", "Vitamin C supports immune function", True),
    (r"\bvitamin\s*c\s*|ascorb", "antioxidant_support", "Vitamin C is an antioxidant", True),
    (r"\bvitamin\s*c\s*|ascorb", "skin_health", "Vitamin C supports skin collagen", True),
    (r"\bvitamin\s*e\s*|tocopherol", "antioxidant_support", "Vitamin E is an antioxidant", False),
    (r"\bvitamin\s*a\s*|retinol|\bbeta[\s-]*carotene", "antioxidant_support", "Vitamin A / beta-carotene supports immunity", True),
    (r"\bbeta[\s-]*carotene|\bcarotene", "eye_health", "Beta-carotene supports eye health", True),
    (r"\bbiotin", "hair_nail_support", "Biotin supports hair/nail health", True),
    (r"\bsilica|\bsilicon\b", "hair_nail_support", "Silica supports hair/skin/nails", False),
    (r"\bsilica|\bsilicon\b", "skin_health", "Silica supports skin", False),
    (r"\bcurcumin|\bturmeric", "antioxidant_support", "Turmeric/curcumin is anti-inflammatory", True),
    (r"\bcurcumin|\bturmeric", "joint health (review)", "Curcumin used in joint care", True),
    (r"\bfish\s*oil|\bepa|\bdha|\bomega[\s-]*3", "heart_health", "Omega-3 supports heart health", False),
    (r"\bfish\s*oil|\bepa|\bdha|\bomega[\s-]*3", "cholesterol_support", "Omega-3 may support cholesterol", True),
    (r"\bcoenzyme\s*q\s*10|\bcoq10|\bubidecarenone|\bubiquinol", "heart_health", "CoQ10 supports cardiovascular health", True),
    (r"\bcoenzyme\s*q\s*10|\bcoq10|\bubidecarenone|\bubiquinol", "energy_support", "CoQ10 supports energy production", True),
    (r"\blutein|\bzeaxanthin|\bbeta[\s-]*carotene", "eye_health", "Lutein/zeaxanthin supports eye health", True),
    (r"\bsilybum|\bmilk\s*thistle", "liver_support", "Milk thistle supports liver function", True),
    (r"\bginkgo", "memory_support (review)", "Ginkgo used for cognitive support", True),
    (r"\bginkgo", "anticoagulant_review_required", "Ginkgo may affect bleeding", True),
    (r"\bginseng|\bsiberian\s*ginseng|\spanax", "energy_support", "Ginseng supports energy", True),
    (r"\bginseng|\bsiberian\s*ginseng|\spanax", "stress_support", "Ginseng is an adaptogen", True),
    (r"\bvalerian|\bsleep|\bpassionflower|\bhops|\bchamomile|\bskullcap", "sleep_support", "Contains sleep-supporting herb", True),
    (r"\bsleep|\bstress", "stress_support", "Stress/sleep product", True),
    (r"\brhodiola|\bwithania|\basiwagandha|\bbrahmi|\bbacopa", "stress_support", "Adaptogen herb", True),
    (r"\bbacopa|\bbrahmi", "nervous_system_support", "Bacopa/Brahmi supports cognitive function", True),
    (r"\blactobacillus|\bbifidobacterium|\bprobiotic", "probiotic_support", "Contains probiotic strains", False),
    (r"\blactobacillus|\bbifidobacterium|\bprobiotic", "gut_health", "Probiotic supports gut health", False),
    (r"\blactobacillus|\bbifidobacterium|\bprobiotic", "immune_support", "Probiotic supports immune health", True),
    (r"\bslippery\s*elm|\bulmus|\bglutamine", "gut_health", "Gut-soothing ingredient", True),
    (r"\bslippery\s*elm|\bulmus|\bglutamine", "gastrointestinal_support (review)", "Gut support ingredient", True),
    (r"\bglucosamine", "joint_health (review)", "Glucosamine used in joint care", True),
    (r"\bhawthorn", "heart_health", "Hawthorn supports cardiovascular function", True),
    (r"\bevening\s*primrose", "women_health", "Evening primrose oil for women's health", True),
    (r"\bevening\s*primrose", "skin_health", "Evening primrose supports skin", True),
    (r"\bvitex|chaste", "women_health", "Vitex supports women's hormonal balance", True),
    (r"\bvitex|chaste", "menopause_review_required", "Vitex used in menstrual/menopause support", True),
    (r"\bmaca", "energy_support", "Maca supports energy/libido", True),
    (r"\bsaw\s*palmetto", "men_health", "Saw palmetto for prostate health", True),
    (r"\bsaw\s*palmetto", "prostate_support (review)", "Saw palmetto for BPH/prostate", True),
    (r"\bblack\s*cohosh", "menopause_review_required", "Black cohosh for menopausal symptoms", True),
    (r"\bblack\s*cohosh", "women_health", "Black cohosh for women's health", True),
    (r"\bsage", "menopause_review_required", "Sage for menopausal symptoms", True),
    (r"\bthyroid", "thyroid_condition_review_required", "Thyroid support product", True),
    (r"\biodine", "thyroid_condition_review_required", "Iodine affects thyroid", True),
    (r"\bnac\b|\bn[\s-]*acetyl[\s-]*cysteine", "antioxidant_support", "NAC is a precursor to glutathione", True),
    (r"\bnac\b|\bn[\s-]*acetyl[\s-]*cysteine", "liver_support", "NAC supports liver detoxification", True),
    (r"\bnac\b|\bn[\s-]*acetyl[\s-]*cysteine", "respiratory_support (review)", "NAC mucolytic", True),
    (r"\balpha[\s-]*lipoic", "antioxidant_support", "Alpha lipoic acid is an antioxidant", True),
    (r"\balpha[\s-]*lipoic", "blood_sugar_support (review)", "Alpha lipoic may affect glucose", True),
    (r"\breishi|\bmaitake|\bshiitake|\bcordyceps|\blion's\s*mane|\bchaga", "immune_support", "Medicinal mushroom", True),
    (r"\breishi|\bmaitake|\bshiitake|\bcordyceps|\blion's\s*mane|\bchaga", "general_multivitamin", "Medicinal mushroom blend", True),
    (r"\bginger", "antioxidant_support", "Ginger is anti-inflammatory", True),
    (r"\bginger", "nausea_support (review)", "Ginger for nausea", True),
    (r"\belderberry|\bechinacea", "immune_support", "Immune-supporting herb", True),
    (r"\bgarlic", "antioxidant_support", "Garlic is antioxidant", True),
    (r"\bgarlic", "anticoagulant_review_required", "Garlic may affect bleeding", True),
    (r"\bberberine", "blood_sugar_support (review)", "Berberine may affect glucose", True),
    (r"\bcinnamon", "blood_sugar_support (review)", "Cinnamon used for glucose metabolism", True),
    (r"\bchromium", "blood_sugar_support (review)", "Chromium for glucose metabolism", True),
    (r"\bfenugreek", "blood_sugar_support (review)", "Fenugreek for glucose/lactation", True),
    (r"\bfenugreek", "breastfeeding_review_required", "Fenugreek traditionally used for lactation", True),
    (r"\bgrape\s*seed", "antioxidant_support", "Grape seed antioxidant", True),
    (r"\bgrape\s*seed", "anticoagulant_review_required", "Grape seed may affect bleeding", True),
    (r"\bresveratrol", "antioxidant_support", "Resveratrol antioxidant", True),
    (r"\bcollagen", "skin_health", "Collagen supports skin", False),
    (r"\bcollagen", "hair_nail_support", "Collagen supports hair/nails", True),
    (r"\blysine", "immune_support", "Lysine for cold sores", True),
    (r"\blysine", "skin_health", "Lysine for skin", True),
    (r"\btyrosine", "energy_support", "Tyrosine for focus/energy", True),
    (r"\btyrosine", "thyroid_condition_review_required", "Tyrosine is a thyroid precursor", True),
    (r"\bcarnitine|\b acetyl[\s-]*l[\s-]*carnitine", "energy_support", "Carnitine for energy/fat metabolism", True),
    (r"\btaurine", "heart_health", "Taurine for cardiovascular", True),
    (r"\btaurine", "energy_support", "Taurine for energy", True),
    (r"\btheanine", "stress_support", "Theanine for relaxation", True),
    (r"\btheanine", "sleep_support", "Theanine for sleep quality", True),
    (r"\btryptophan", "sleep_support", "Tryptophan for sleep/mood", True),
    (r"\btryptophan", "antidepressant_review_required", "Tryptophan + SSRIs risk serotonin syndrome", True),
]

# Avoid-if tags by ingredient (conservative — most require pharmacist review)
AVOID_IF_RULES: list[tuple[str, str, str, bool]] = [
    (r"\biron\b", "antacid_separation", "Iron absorption reduced by antacids", True),
    (r"\biron\b", "doac", "Iron with DOACs: pharmacist review", True),
    (r"\biron\b", "tetracycline_antibiotic", "Iron + tetracycline: separate by 2h", True),
    (r"\biron\b", "quinolone_antibiotic", "Iron + quinolone: separate by 2h", True),
    (r"\biron\b", "bisphosphonate", "Iron + bisphosphonate: separate", True),
    (r"\biron\b", "levothyroxine", "Iron + levothyroxine: separate by 4h", True),
    (r"\biron\b", "constipation_caution", "Iron may cause constipation", True),
    (r"\bcalcium\b", "tetracycline_antibiotic", "Calcium + tetracycline: separate by 2h", True),
    (r"\bcalcium\b", "quinolone_antibiotic", "Calcium + quinolone: separate by 2h", True),
    (r"\bcalcium\b", "bisphosphonate", "Calcium + bisphosphonate: separate", True),
    (r"\bcalcium\b", "levothyroxine", "Calcium + levothyroxine: separate by 4h", True),
    (r"\bcalcium\b", "renal_impairment_caution", "Calcium: hypercalcaemia risk in renal impairment", True),
    (r"\bmagnesium\b", "tetracycline_antibiotic", "Magnesium + tetracycline: separate by 2h", True),
    (r"\bmagnesium\b", "quinolone_antibiotic", "Magnesium + quinolone: separate by 2h", True),
    (r"\bmagnesium\b", "bisphosphonate", "Magnesium + bisphosphonate: separate", True),
    (r"\bmagnesium\b", "renal_impairment_caution", "Magnesium accumulation in renal impairment", True),
    (r"\bzinc\b", "tetracycline_antibiotic", "Zinc + tetracycline: separate by 2h", True),
    (r"\bzinc\b", "quinolone_antibiotic", "Zinc + quinolone: separate by 2h", True),
    (r"\bzinc\b", "penicillamine", "Zinc + penicillamine: separate", True),
    (r"\bcolecalciferol|\bcholecalciferol|\bvitamin\s*d", "hypercalcaemia_caution", "Vitamin D: monitor in renal impairment", True),
    (r"\bcolecalciferol|\bcholecalciferol|\bvitamin\s*d", "renal_impairment_caution", "Vitamin D: renal stone/hypercalcaemia risk", True),
    (r"\bcolecalciferol|\bcholecalciferol|\bvitamin\s*d", "sarcoidosis_caution", "Vitamin D: caution in sarcoidosis", True),
    (r"\bcolecalciferol|\bcholecalciferol|\bvitamin\s*d", "hyperparathyroidism_caution", "Vitamin D: caution in hyperparathyroidism", True),
    (r"\biode\b|\bpotassium\s*iodide", "thyroid_condition_review_required", "Iodine affects thyroid function", True),
    (r"\bginkgo", "anticoagulant_review_required", "Ginkgo may increase bleeding risk", True),
    (r"\bginkgo", "antiplatelet", "Ginkgo + antiplatelets: monitor", True),
    (r"\bginkgo", "warfarin", "Ginkgo + warfarin: monitor INR", True),
    (r"\bginkgo", "surgery_caution", "Ginkgo: stop before surgery", True),
    (r"\bgarlic", "anticoagulant_review_required", "Garlic may increase bleeding risk", True),
    (r"\bgarlic", "antiplatelet", "Garlic + antiplatelets: monitor", True),
    (r"\bgarlic", "surgery_caution", "Garlic: stop before surgery", True),
    (r"\bginger", "anticoagulant_review_required", "High-dose ginger may affect bleeding", True),
    (r"\bginger", "antiplatelet", "Ginger + antiplatelets: monitor", True),
    (r"\bgrape\s*seed", "anticoagulant_review_required", "Grape seed may affect bleeding", True),
    (r"\bgrape\s*seed", "warfarin", "Grape seed + warfarin: monitor", True),
    (r"\bcurcumin|\bturmeric", "anticoagulant_review_required", "High-dose turmeric/curcumin may affect bleeding", True),
    (r"\bcurcumin|\bturmeric", "antiplatelet", "Turmeric + antiplatelets: monitor", True),
    (r"\bfish\s*oil|\bepa|\bdha|\bomega[\s-]*3", "anticoagulant_review_required", "High-dose fish oil may increase bleeding risk", True),
    (r"\bfish\s*oil|\bepa|\bdha|\bomega[\s-]*3", "antiplatelet", "Fish oil + antiplatelets: monitor at high dose", True),
    (r"\bvitamin\s*e\s*|tocopherol", "anticoagulant_review_required", "High-dose vitamin E may increase bleeding", True),
    (r"\bvitamin\s*e\s*|tocopherol", "warfarin", "High-dose vitamin E + warfarin: monitor", True),
    (r"\bcranberry", "warfarin", "Cranberry + warfarin: monitor INR", True),
    (r"\bcranberry", "anticoagulant_review_required", "Cranberry may affect warfarin", True),
    (r"\blactobacillus|\bbifidobacterium|\bprobiotic", "immunosuppressed_review_required", "Probiotics in immunocompromised: case-by-case", True),
    (r"\blactobacillus|\bbifidobacterium|\bprobiotic", "central_line_caution", "Probiotic with central line: risk of bacteraemia", True),
    (r"\bvalerian|\bpassionflower|\bhops", "sedative", "Sedating herb + CNS depressants: monitor", True),
    (r"\bvalerian|\bpassionflower|\bhops", "antidepressant_review_required", "Sedating herbs + antidepressants: monitor", True),
    (r"\bvalerian|\bpassionflower|\bhops", "driving_caution", "May impair driving/machinery", True),
    (r"\bsaw\s*palmetto", "anticoagulant_review_required", "Saw palmetto may increase bleeding", True),
    (r"\bsaw\s*palmetto", "antiplatelet", "Saw palmetto + antiplatelets: monitor", True),
    (r"\bmaca", "thyroid_condition_review_required", "Maca contains goitrogens", True),
    (r"\bbacopa|\bbrahmi", "antidepressant_review_required", "Bacopa + antidepressants: theoretical serotonin risk", True),
    (r"\bbacopa|\bbrahmi", "thyroid_condition_review_required", "Bacopa may affect thyroid", True),
    (r"\bst[\s\.]*john", "antidepressant_review_required", "St John's Wort: multiple interactions", True),
    (r"\bst[\s\.]*john", "anticoagulant_review_required", "St John's Wort reduces warfarin effect", True),
    (r"\bst[\s\.]*john", "oral_contraceptive", "St John's Wort reduces OCP efficacy", True),
    (r"\bst[\s\.]*john", "immunosuppressant", "St John's Wort reduces ciclosporin/tacrolimus", True),
    (r"\bst[\s\.]*john", "digoxin", "St John's Wort reduces digoxin", True),
    (r"\bnac\b|\bn[\s-]*acetyl[\s-]*cysteine", "anticoagulant_review_required", "NAC theoretical bleeding risk", True),
    (r"\btyrosine", "thyroid_condition_review_required", "Tyrosine is a thyroid hormone precursor", True),
    (r"\btyrosine", "antidepressant_review_required", "Tyrosine + MAOIs: risk of hypertensive crisis", True),
    (r"\bchromium", "antidiabetic", "Chromium may enhance hypoglycaemics", True),
    (r"\bcinnamon", "antidiabetic", "Cinnamon may affect glucose", True),
    (r"\bberberine", "antidiabetic", "Berberine may enhance hypoglycaemics", True),
    (r"\balpha[\s-]*lipoic", "antidiabetic", "Alpha lipoic may enhance hypoglycaemics", True),
    (r"\bfenugreek", "antidiabetic", "Fenugreek may affect glucose", True),
    (r"\bglucosamine", "warfarin", "Glucosamine + warfarin: case reports of INR rise", True),
    (r"\bglucosamine", "anticoagulant_review_required", "Glucosamine may affect bleeding", True),
    (r"\bglucosamine", "shellfish_allergy_caution", "Glucosamine often shellfish-derived", True),
    (r"\bsilybum|\bmilk\s*thistle", "immunosuppressant", "Milk thistle affects CYP3A4", True),
    (r"\bsilybum|\bmilk\s*thistle", "oral_contraceptive", "Milk thistle affects OCP metabolism", True),
    (r"\bgrapefruit", "statin", "Grapefruit + statins: avoid", True),
    (r"\bgrapefruit", "immunosuppressant", "Grapefruit + immunosuppressants: avoid", True),
]

# Patient group flags — derived from cautions and ingredients
PATIENT_GROUP_FROM_CAUTION: list[tuple[str, str, str]] = [
    (r"pregnan", "pregnancy_review_required", "Caution in pregnancy"),
    (r"breast[\s-]?feed|lactat", "breastfeeding_review_required", "Caution in breastfeeding"),
    (r"child|paediatric|pediatric|infant", "child_review_required", "Caution in children"),
    (r"renal|kidney", "renal_impairment_caution", "Caution in renal impairment"),
    (r"liver|hepatic", "liver_impairment_caution", "Caution in liver impairment"),
    (r"epilep|seizure", "seizure_disorder_review_required", "Caution in seizure disorders"),
    (r"surger", "surgery_caution", "Stop before surgery"),
]


def classify_tags(ingredients: list[dict], cautions: list[dict], features: list[str],
                  name: str) -> dict:
    """Return ClinicalUseTags, AvoidIfTags, MedicineInteractionFlags lists."""
    clinical_tags: list[dict] = []
    avoid_tags: list[dict] = []
    med_flags: set[str] = set()

    # Combine all ingredient names + feature text for matching
    ing_text = " ".join(
        i.get("ingredient_name", "") + " " + i.get("equivalent_name", "")
        for i in ingredients
    ).lower()
    features_text = " ".join(features).lower()
    combined = ing_text + " " + features_text + " " + name.lower()

    # Apply clinical use rules
    for pattern, tag, reason, requires_review in CLINICAL_USE_RULES:
        if re.search(pattern, combined):
            clinical_tags.append({
                "TagType": "clinical_use",
                "Tag": tag,
                "Reason": reason,
                "RequiresPharmacistReview": requires_review,
            })

    # Apply avoid-if rules
    for pattern, tag, reason, requires_review in AVOID_IF_RULES:
        if re.search(pattern, combined):
            avoid_tags.append({
                "TagType": "avoid_if",
                "Tag": tag,
                "Reason": reason,
                "RequiresPharmacistReview": requires_review,
            })
            # Map to medicine interaction flag if applicable
            for med in ["warfarin", "anticoagulant", "antiplatelet", "doac",
                        "levothyroxine", "tetracycline_antibiotic", "quinolone_antibiotic",
                        "bisphosphonate", "methotrexate", "digoxin",
                        "antihypertensive", "antidiabetic", "sedative",
                        "antidepressant", "immunosuppressant", "oral_contraceptive",
                        "hormone_therapy", "statin", "ppi", "corticosteroid", "diuretic",
                        "penicillamine"]:
                if tag == med or med in tag:
                    med_flags.add(med)

    # Add patient group tags from cautions
    for c in cautions:
        ct = c.get("caution_text", "").lower()
        for pattern, tag, reason in PATIENT_GROUP_FROM_CAUTION:
            if re.search(pattern, ct):
                avoid_tags.append({
                    "TagType": "patient_group",
                    "Tag": tag,
                    "Reason": f"Source caution: '{c['caution_text'][:60]}...'",
                    "RequiresPharmacistReview": True,
                })

    # Pregnancy product (any product with "Pregnancy" in name) — always review
    if "pregnan" in name.lower():
        avoid_tags.append({
            "TagType": "patient_group",
            "Tag": "pregnancy_review_required",
            "Reason": "Product name indicates pregnancy use",
            "RequiresPharmacistReview": True,
        })

    # Dedupe tags
    seen = set()
    cu = []
    for t in clinical_tags:
        k = (t["TagType"], t["Tag"])
        if k not in seen:
            seen.add(k); cu.append(t)
    av = []
    seen2 = set()
    for t in avoid_tags:
        k = (t["TagType"], t["Tag"])
        if k not in seen2:
            seen2.add(k); av.append(t)

    return {
        "clinical_use_tags": cu,
        "avoid_if_tags": av,
        "medicine_interaction_flags": sorted(med_flags),
    }


def generate_counselling_points(p: dict) -> list[dict]:
    """Generate pharmacist-facing counselling points for a product."""
    out: list[dict] = []
    name = p["ProductName"]
    ings = p.get("_ingredients", [])
    cautions = p.get("_cautions_list", [])
    interactions = p.get("_interactions_list", [])
    tags = p.get("_tags_cache") or {}
    clinical_tags = tags.get("clinical_use_tags", [])
    avoid_tags = tags.get("avoid_if_tags", [])

    def has_tag(prefix: str) -> bool:
        return any(t["Tag"].startswith(prefix) for t in clinical_tags) or any(
            t["Tag"].startswith(prefix) for t in avoid_tags)

    # 1. Why this may be relevant
    relevant = []
    for ct in clinical_tags[:3]:
        if not ct.get("RequiresPharmacistReview") or True:
            tag = ct["Tag"].replace("_", " ").capitalize()
            relevant.append(
                f"Pharmacist point: This product is tagged for {tag} ({ct['Reason']})."
            )
    if not relevant and ings:
        ing_names = ", ".join(i["ingredient_name"][:30] for i in ings[:3])
        relevant.append(
            f"Pharmacist point: Active ingredients include {ing_names}."
        )
    if not relevant:
        relevant.append(
            "Pharmacist point: Review source indication text and confirm clinical fit for this patient."
        )

    for x in relevant[:3]:
        out.append({
            "counselling_type": "safety_check",
            "pharmacist_point": x,
            "patient_friendly_version": "",
            "source_page": p.get("SourcePage", ""),
            "extraction_confidence": "High",
        })

    # 2. Check before recommending
    checks = []
    if p.get("_cautions_list"):
        for c in cautions[:2]:
            checks.append(
                f"Pharmacist point: Check whether any of the following applies to this patient — source notes: \"{c['caution_text'][:120]}\""
            )
    # Check duplication
    if ings:
        ing_summary = ", ".join(i["ingredient_name"][:30] for i in ings[:3])
        checks.append(
            f"Pharmacist point: Check whether the patient is already taking {ing_summary} or another product containing the same ingredients to avoid duplication."
        )
    # Check interactions
    if interactions:
        intx_summary = "; ".join(i["interacting_medicine_or_class"] for i in interactions[:2] if i["interacting_medicine_or_class"] != "unspecified")
        if intx_summary:
            checks.append(
                f"Pharmacist point: Review current medications for potential interactions with: {intx_summary}."
            )
    if not checks:
        checks.append(
            "Pharmacist point: Confirm no contraindications and no significant medicine interactions before recommending."
        )
    for x in checks[:3]:
        out.append({
            "counselling_type": "how_to_take" if "how" in x.lower() else "safety_check",
            "pharmacist_point": x,
            "patient_friendly_version": "Before adding this, let's check your other medicines and conditions to make sure it's right for you.",
            "source_page": p.get("SourcePage", ""),
            "extraction_confidence": "High",
        })

    # 3. How to counsel
    how = []
    if p.get("AdultDose"):
        how.append(
            f"Pharmacist point: Adult dose per source: {p['AdultDose'][:200]}"
        )
        out.append({
            "counselling_type": "how_to_take",
            "pharmacist_point": how[-1],
            "patient_friendly_version": f"For adults: {p['AdultDose'][:200]}",
            "source_page": p.get("SourcePage", ""),
            "extraction_confidence": "High",
        })
    if has_tag("tetracycline") or has_tag("quinolone") or has_tag("bisphosphonate") or has_tag("levothyroxine"):
        out.append({
            "counselling_type": "separation_from_medicines",
            "pharmacist_point": "Pharmacist point: This product contains minerals that may bind to some medicines. Counsel patient to take 2–4 hours apart from antibiotics (tetracycline/quinolone), bisphosphonates, levothyroxine, or iron.",
            "patient_friendly_version": "Take this at least 2 hours apart from some other medicines — I'll explain which ones.",
            "source_page": p.get("SourcePage", ""),
            "extraction_confidence": "High",
        })
    if has_tag("iron") or has_tag("calcium") or has_tag("magnesium"):
        out.append({
            "counselling_type": "timing",
            "pharmacist_point": "Pharmacist point: Mineral supplements are often best taken with food to reduce GI upset, but separate from some medicines (see above).",
            "patient_friendly_version": "Taking this with food can help reduce stomach upset. We may need to space it from some of your other medicines.",
            "source_page": p.get("SourcePage", ""),
            "extraction_confidence": "Medium",
        })
    if has_tag("probiotic"):
        out.append({
            "counselling_type": "how_to_take",
            "pharmacist_point": "Pharmacist point: Probiotics — counsel patient to take with food and check storage requirements (some need refrigeration).",
            "patient_friendly_version": "Take this with a meal. Some probiotic products need to be kept in the fridge — I'll let you know if yours does.",
            "source_page": p.get("SourcePage", ""),
            "extraction_confidence": "Medium",
        })
    if has_tag("vitamin_d") or has_tag("calcium"):
        out.append({
            "counselling_type": "timing",
            "pharmacist_point": "Pharmacist point: Vitamin D is fat-soluble — best absorbed with a meal containing fat.",
            "patient_friendly_version": "Take this with a meal that has some fat in it (e.g. breakfast with eggs or avocado) for best absorption.",
            "source_page": p.get("SourcePage", ""),
            "extraction_confidence": "Medium",
        })

    # 4. When to refer / avoid
    if p.get("_cautions_list") or p.get("_interactions_list"):
        flags = [c for c in cautions if c.get("severity") == "high"]
        if flags:
            txt = flags[0]["caution_text"]
            out.append({
                "counselling_type": "when_to_refer",
                "pharmacist_point": f"Pharmacist point: Refer to/consult prescriber if any of the following: {txt[:200]}",
                "patient_friendly_version": "Please let me or your doctor know if any of these apply to you.",
                "source_page": p.get("SourcePage", ""),
                "extraction_confidence": "High",
            })
        else:
            out.append({
                "counselling_type": "when_to_refer",
                "pharmacist_point": "Pharmacist point: Refer to GP if patient is pregnant, breastfeeding, on multiple medicines, or has any chronic health condition before recommending.",
                "patient_friendly_version": "If you're pregnant, breastfeeding, on other medicines, or have any health conditions, please let me know before starting this.",
                "source_page": p.get("SourcePage", ""),
                "extraction_confidence": "Medium",
            })

    return out


def generate_safety_rules(products: list[dict]) -> list[dict]:
    """Generate draft Safety Rules from the parsed product data."""
    rules = []
    rid = 0

    def add_rule(name, trigger_med, trigger_drug_class, trigger_patient,
                 trigger_ingredient, trigger_tag, action, severity,
                 message, talking_point, source_basis, requires_review=True):
        nonlocal rid
        rid += 1
        rules.append({
            "RuleID": f"RULE-{rid:03d}",
            "RuleName": name,
            "TriggerMedication": trigger_med,
            "TriggerDrugClass": trigger_drug_class,
            "TriggerPatientFactor": trigger_patient,
            "TriggerIngredient": trigger_ingredient,
            "TriggerProductTag": trigger_tag,
            "Action": action,
            "Severity": severity,
            "PharmacistMessage": message,
            "PatientTalkingPoint": talking_point,
            "SourceBasis": source_basis,
            "RequiresPharmacistReview": requires_review,
        })

    # Standard separation rules
    add_rule(
        "Magnesium/Calcium/Iron/Zinc with Tetracycline",
        "", "tetracycline", "", "magnesium|calcium|iron|zinc", "",
        "separate_dosing", "medium",
        "Separate dose by at least 2 hours from tetracycline antibiotics",
        "Take this 2 hours apart from your antibiotic.",
        "Generated from product ingredient pattern. Common pharmacist knowledge.",
        True,
    )
    add_rule(
        "Magnesium/Calcium/Iron/Zinc with Quinolone",
        "", "quinolone", "", "magnesium|calcium|iron|zinc", "",
        "separate_dosing", "medium",
        "Separate dose by at least 2 hours from quinolone antibiotics (ciprofloxacin, norfloxacin)",
        "Take this 2 hours apart from your antibiotic.",
        "Generated from product ingredient pattern.",
        True,
    )
    add_rule(
        "Magnesium/Calcium/Iron with Bisphosphonate",
        "", "bisphosphonate", "", "magnesium|calcium|iron", "",
        "separate_dosing", "medium",
        "Separate dose from bisphosphonate (alendronate, risedronate) — take calcium/magnesium/iron at different time of day",
        "Take this at a different time of day from your bone medication.",
        "Generated from product ingredient pattern.",
        True,
    )
    add_rule(
        "Iron/Calcium/Magnesium with Levothyroxine",
        "levothyroxine", "", "", "iron|calcium|magnesium", "",
        "separate_dosing", "medium",
        "Separate from levothyroxine by at least 4 hours",
        "Take this 4 hours apart from your thyroid medication.",
        "Generated from product ingredient pattern.",
        True,
    )
    add_rule(
        "Magnesium products in renal impairment",
        "", "", "renal_impairment", "magnesium", "",
        "pharmacist_review_required", "high",
        "Magnesium may accumulate in renal impairment. Pharmacist review required.",
        "If you have any kidney problems, please let me know before starting this.",
        "Generated from ingredient profile + clinical knowledge.",
        True,
    )
    add_rule(
        "Vitamin D/Calcium in renal impairment / hypercalcaemia",
        "", "", "renal_impairment|hyperparathyroidism|sarcoidosis",
        "colecalciferol|vitamin d|calcium", "",
        "pharmacist_review_required", "high",
        "Vitamin D and calcium products can worsen hypercalcaemia and renal stones. Pharmacist review required.",
        "If you have any kidney, parathyroid, or calcium problems, please tell me before taking this.",
        "Generated from ingredient profile + clinical knowledge.",
        True,
    )
    add_rule(
        "Anticoagulant/Antiplatelet — bleeding-risk herbs",
        "warfarin|apixaban|rivaroxaban|dabigatran", "anticoagulant|antiplatelet", "",
        "ginkgo|garlic|fish oil|curcumin|turmeric|cranberry|grape seed|vitamin e|ginger|saw palmetto", "",
        "pharmacist_review_required", "high",
        "Several herbs may increase bleeding risk when combined with anticoagulants/antiplatelets. Pharmacist review required before recommending.",
        "If you're on any blood-thinning medication, please let me know before taking this.",
        "Generated from product ingredient pattern + common pharmacist knowledge.",
        True,
    )
    add_rule(
        "Sedating herbs with CNS depressants",
        "", "sedative|CNS depressant", "", "valerian|passionflower|hops", "",
        "pharmacist_review_required", "medium",
        "Sedating herbs may potentiate CNS depressant effects. Pharmacist review required.",
        "If you take anything for sleep or anxiety, please tell me before taking this.",
        "Generated from ingredient pattern + clinical knowledge.",
        True,
    )
    add_rule(
        "Pregnancy product — always pharmacist review",
        "", "", "pregnancy", "", "pregnancy_product",
        "pharmacist_review_required", "high",
        "Pregnancy products must be reviewed by pharmacist before recommendation; do not auto-approve.",
        "Pregnancy and breastfeeding need extra care — let's check this is right for you.",
        "Workflow rule (no automatic pregnancy recommendations).",
        True,
    )
    add_rule(
        "Iron — constipation and absorption counselling",
        "", "", "", "iron", "",
        "allow_with_counselling", "low",
        "Iron may cause constipation; counsel on increasing fluids/fibre. Separate from tea, coffee, dairy, antacids.",
        "Iron can sometimes cause constipation — drink plenty of water. Avoid taking with tea, coffee, milk, or antacids.",
        "Common pharmacist counselling for iron supplements.",
        True,
    )
    add_rule(
        "Probiotics in immunocompromised patients",
        "", "", "immunosuppressed|immunocompromised", "lactobacillus|bifidobacterium|probiotic", "",
        "pharmacist_review_required", "medium",
        "Probiotics in immunocompromised/central-line patients: case-by-case review required.",
        "If you have a weakened immune system or a central line, please let me know before taking this.",
        "Common pharmacist knowledge + product ingredient pattern.",
        True,
    )
    add_rule(
        "St John's Wort — multiple interactions",
        "warfarin|ssri|oral contraceptive|ciclosporin|tacrolimus|digoxin",
        "anticoagulant|antidepressant|immunosuppressant|antiviral", "",
        "hypericum|st john", "",
        "pharmacist_review_required", "high",
        "St John's Wort has multiple significant interactions. DO NOT recommend without thorough medication review.",
        "This herb interacts with many medicines — we need to do a full medication check before you start it.",
        "Generated from product ingredient + TGA guidance.",
        True,
    )
    add_rule(
        "Iodine — thyroid condition",
        "", "", "thyroid_condition", "iodine|potassium iodide", "",
        "pharmacist_review_required", "high",
        "Iodine affects thyroid function. Pharmacist review required in thyroid disease.",
        "If you have any thyroid condition, please let me know before taking this.",
        "Generated from ingredient + clinical knowledge.",
        True,
    )
    add_rule(
        "Berberine / Alpha Lipoic / Chromium / Cinnamon / Fenugreek — glucose interactions",
        "", "antidiabetic", "diabetes", "berberine|alpha lipoic|chromium|cinnamon|fenugreek", "",
        "pharmacist_review_required", "medium",
        "Ingredients may affect blood glucose. Pharmacist review required in diabetic patients.",
        "If you have diabetes or take diabetes medicine, please tell me before taking this.",
        "Generated from ingredient profile + clinical knowledge.",
        True,
    )
    add_rule(
        "Glucosamine + Warfarin",
        "warfarin", "anticoagulant", "", "glucosamine", "",
        "pharmacist_review_required", "medium",
        "Case reports of INR rise with glucosamine + warfarin. Monitor INR closely.",
        "If you're on warfarin, we should monitor you more closely if you start this.",
        "Generated from ingredient + published case reports.",
        True,
    )
    add_rule(
        "Cranberry + Warfarin",
        "warfarin", "anticoagulant", "", "cranberry", "",
        "pharmacist_review_required", "medium",
        "Cranberry may affect warfarin. Monitor INR.",
        "If you're on warfarin, let me know before you start this so we can keep an eye on your levels.",
        "Generated from ingredient + clinical knowledge.",
        True,
    )
    add_rule(
        "Tyrosine + MAOI",
        "", "antidepressant", "mao_treated", "tyrosine", "",
        "pharmacist_review_required", "high",
        "Tyrosine + MAOI: theoretical risk of hypertensive crisis.",
        "If you're on any MAOI antidepressant, please let me know before taking this.",
        "Generated from ingredient + clinical knowledge.",
        True,
    )

    return rules


def main():
    products = json.loads(
        (INTERMEDIATE / "products_parsed.json").read_text(encoding="utf-8")
    )
    log.info("Loaded %d products", len(products))

    # ---- Tag each product ----
    for p in products:
        tags = classify_tags(
            ingredients=p.get("_ingredients", []),
            cautions=p.get("_cautions_list", []),
            features=p.get("_features_benefits", []),
            name=p.get("ProductName", ""),
        )
        p["_tags_cache"] = tags
        p["ClinicalUseTags"] = [t["Tag"] for t in tags["clinical_use_tags"]]
        p["AvoidIfTags"] = [t["Tag"] for t in tags["avoid_if_tags"]]
        p["MedicineInteractionFlags"] = tags["medicine_interaction_flags"]
        # Generate counselling
        p["_counselling_points"] = generate_counselling_points(p)
        # Build a short summary
        summary_bits = []
        if p.get("AdultDose"):
            summary_bits.append(f"Adult dose: {p['AdultDose'][:120]}")
        if p["_ingredients"]:
            summary_bits.append(f"Key ingredients: {', '.join(i['ingredient_name'][:30] for i in p['_ingredients'][:3])}")
        if p["_cautions_list"]:
            summary_bits.append(f"Cautions: {len(p['_cautions_list'])} flagged")
        p["CounsellingPointSummary"] = " | ".join(summary_bits)

    # ---- Generate safety rules ----
    rules = generate_safety_rules(products)
    log.info("Generated %d draft safety rules", len(rules))

    # Save
    (INTERMEDIATE / "products_with_tags.json").write_text(
        json.dumps(products, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (INTERMEDIATE / "safety_rules_draft.json").write_text(
        json.dumps(rules, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Wrote products_with_tags.json and safety_rules_draft.json")

    # Stats
    total_cu_tags = sum(len(p["ClinicalUseTags"]) for p in products)
    total_av_tags = sum(len(p["AvoidIfTags"]) for p in products)
    total_med_flags = sum(len(p["MedicineInteractionFlags"]) for p in products)
    total_couns = sum(len(p["_counselling_points"]) for p in products)
    log.info("Total clinical use tags: %d", total_cu_tags)
    log.info("Total avoid-if tags: %d", total_av_tags)
    log.info("Total medicine interaction flags: %d", total_med_flags)
    log.info("Total counselling points: %d", total_couns)


if __name__ == "__main__":
    main()
