#!/usr/bin/env python3
"""08_validate_outputs.py — Validate the final outputs and produce validation_report.xlsx.

Checks:
  - Duplicate product names
  - Products missing AUST L numbers
  - Products missing doses
  - Products missing ingredients
  - Products missing cautions
  - Products with possible extraction errors
  - Products with inconsistent data between Word and Excel
  - Products requiring pharmacist review
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import INTERMEDIATE, OUTPUT, get_logger

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

log = get_logger("08_validate_outputs")

HEADER_FONT = Font(bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="C00000", end_color="C00000", fill_type="solid")
WRAP = Alignment(wrap_text=True, vertical="top")


def write_headers(ws, headers):
    for ci, h in enumerate(headers, 1):
        c = ws.cell(row=1, column=ci, value=h)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="left")
    for ci, h in enumerate(headers, 1):
        ws.column_dimensions[get_column_letter(ci)].width = max(12, min(50, len(str(h)) + 4))


def main():
    products = json.loads(
        (INTERMEDIATE / "products_with_tags.json").read_text(encoding="utf-8")
    )
    issues_raw = json.loads(
        (INTERMEDIATE / "extraction_issues_raw.json").read_text(encoding="utf-8")
    )
    candidates = json.loads(
        (INTERMEDIATE / "product_candidates.json").read_text(encoding="utf-8")
    )
    toc = json.loads(
        (INTERMEDIATE / "excel_product_pages.json").read_text(encoding="utf-8")
    )

    log.info("Loaded %d products, %d issues, %d candidates", len(products), len(issues_raw), len(candidates["candidates"]))

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    # --- Sheet 1: Summary ---
    ws = wb.create_sheet("Summary")
    summary_rows = [
        ("Validation date", __import__("datetime").datetime.now().isoformat(timespec="seconds")),
        ("Source files",
         "herbsofgold_technical_manual.pdf; herbsofgold_technical_manual.docx; WJ herbsofgold_technical_manual.xlsx"),
        ("Total candidate products", len(candidates["candidates"])),
        ("TOC-only extras (not in DOCX H1)", len(candidates["toc_only_extras"])),
        ("Products exported", len(products)),
        ("Products with ingredients", sum(1 for p in products if p.get("_ingredients"))),
        ("Products missing ingredients", sum(1 for p in products if not p.get("_ingredients"))),
        ("Products with adult dose", sum(1 for p in products if p.get("AdultDose"))),
        ("Products missing dose", sum(1 for p in products if not p.get("AdultDose") and not p.get("ChildDose"))),
        ("Products with cautions", sum(1 for p in products if p.get("_cautions_list"))),
        ("Products missing cautions", sum(1 for p in products if not p.get("_cautions_list"))),
        ("Products missing dosage form", sum(1 for p in products if p.get("DosageForm") in ("", "unknown"))),
        ("Products missing AUST L", sum(1 for p in products if not p.get("AUSTL"))),
        ("High confidence extractions", sum(1 for p in products if p.get("ExtractionConfidence") == "High")),
        ("Medium confidence extractions", sum(1 for p in products if p.get("ExtractionConfidence") == "Medium")),
        ("Low confidence extractions", sum(1 for p in products if p.get("ExtractionConfidence") == "Low")),
        ("Total clinical-use tags applied", sum(len(p.get("ClinicalUseTags", [])) for p in products)),
        ("Total avoid-if tags applied", sum(len(p.get("AvoidIfTags", [])) for p in products)),
        ("Total medicine interaction flags", sum(len(p.get("MedicineInteractionFlags", [])) for p in products)),
        ("Total counselling points generated", sum(len(p.get("_counselling_points", [])) for p in products)),
        ("Total draft safety rules", 17),
        ("Total extraction issues", len(issues_raw)),
    ]
    ws.cell(row=1, column=1, value="Metric").font = HEADER_FONT
    ws.cell(row=1, column=1).fill = HEADER_FILL
    ws.cell(row=1, column=2, value="Value").font = HEADER_FONT
    ws.cell(row=1, column=2).fill = HEADER_FILL
    ws.column_dimensions["A"].width = 50
    ws.column_dimensions["B"].width = 50
    for ri, (k, v) in enumerate(summary_rows, start=2):
        ws.cell(row=ri, column=1, value=k).alignment = WRAP
        ws.cell(row=ri, column=2, value=str(v)).alignment = WRAP

    # --- Sheet 2: Duplicate product names ---
    ws = wb.create_sheet("Duplicate_Product_Names")
    headers = ["ProductID", "ProductName", "ProductName_Normalised", "Note"]
    write_headers(ws, headers)
    seen: dict[str, list[str]] = {}
    for p in products:
        n = p.get("ProductName_Normalised", "")
        seen.setdefault(n, []).append(p["ProductID"])
    ri = 2
    for n, pids in seen.items():
        if len(pids) > 1:
            p = next(x for x in products if x["ProductID"] == pids[0])
            ws.cell(row=ri, column=1, value=pids[0])
            ws.cell(row=ri, column=2, value=p["ProductName"])
            ws.cell(row=ri, column=3, value=n)
            ws.cell(row=ri, column=4, value=f"Duplicate normalised name; PIDs: {', '.join(pids)}")
            for ci in range(1, 5):
                ws.cell(row=ri, column=ci).alignment = WRAP
            ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(no duplicates found)")

    # --- Sheet 3: Missing AUST L ---
    ws = wb.create_sheet("Missing_AUSTL")
    headers = ["ProductID", "ProductName", "SourcePage", "ExtractionConfidence", "Note"]
    write_headers(ws, headers)
    ri = 2
    for p in products:
        if not p.get("AUSTL"):
            ws.cell(row=ri, column=1, value=p["ProductID"])
            ws.cell(row=ri, column=2, value=p["ProductName"])
            ws.cell(row=ri, column=3, value=p.get("SourcePage", ""))
            ws.cell(row=ri, column=4, value=p.get("ExtractionConfidence", ""))
            ws.cell(row=ri, column=5, value="AUST L not present in source manual. Pharmacist must verify via TGA ARTG.")
            for ci in range(1, 6):
                ws.cell(row=ri, column=ci).alignment = WRAP
            ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(no missing AUST L)")

    # --- Sheet 4: Missing doses ---
    ws = wb.create_sheet("Missing_Doses")
    headers = ["ProductID", "ProductName", "AdultDose", "ChildDose", "SourcePage", "Note"]
    write_headers(ws, headers)
    ri = 2
    for p in products:
        if not p.get("AdultDose") and not p.get("ChildDose"):
            ws.cell(row=ri, column=1, value=p["ProductID"])
            ws.cell(row=ri, column=2, value=p["ProductName"])
            ws.cell(row=ri, column=3, value=p.get("AdultDose", ""))
            ws.cell(row=ri, column=4, value=p.get("ChildDose", ""))
            ws.cell(row=ri, column=5, value=p.get("SourcePage", ""))
            ws.cell(row=ri, column=6, value="No adult/child dose direction found in DIRECTIONS FOR USE block.")
            for ci in range(1, 7):
                ws.cell(row=ri, column=ci).alignment = WRAP
            ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(no missing doses)")

    # --- Sheet 5: Missing ingredients ---
    ws = wb.create_sheet("Missing_Ingredients")
    headers = ["ProductID", "ProductName", "SourcePage", "Confidence", "Note"]
    write_headers(ws, headers)
    ri = 2
    for p in products:
        if not p.get("_ingredients"):
            ws.cell(row=ri, column=1, value=p["ProductID"])
            ws.cell(row=ri, column=2, value=p["ProductName"])
            ws.cell(row=ri, column=3, value=p.get("SourcePage", ""))
            ws.cell(row=ri, column=4, value=p.get("ExtractionConfidence", ""))
            ws.cell(row=ri, column=5, value=(
                "No 'Each X contains' block with discrete strengths found. "
                "Manual may describe ingredients in prose (e.g. 'It contains: Riboflavin-5-phosphate...') "
                "or have multi-line ingredients. Pharmacist must extract manually or check source."))
            for ci in range(1, 6):
                ws.cell(row=ri, column=ci).alignment = WRAP
            ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(none missing)")

    # --- Sheet 6: Missing cautions ---
    ws = wb.create_sheet("Missing_Cautions")
    headers = ["ProductID", "ProductName", "SourcePage", "Note"]
    write_headers(ws, headers)
    ri = 2
    for p in products:
        if not p.get("_cautions_list"):
            ws.cell(row=ri, column=1, value=p["ProductID"])
            ws.cell(row=ri, column=2, value=p["ProductName"])
            ws.cell(row=ri, column=3, value=p.get("SourcePage", ""))
            ws.cell(row=ri, column=4, value=(
                "No cautions text extracted. "
                "Absence of cautions in source is NOT proof of safety. "
                "Pharmacist review required before recommending."))
            for ci in range(1, 5):
                ws.cell(row=ri, column=ci).alignment = WRAP
            ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(none missing)")

    # --- Sheet 7: Possible extraction errors ---
    ws = wb.create_sheet("Possible_Errors")
    headers = ["ProductID", "ProductName", "Issue", "Detail", "SourcePage", "Severity"]
    write_headers(ws, headers)
    ri = 2
    for p in products:
        # Heuristic: a product is flagged if it has an unusual combination
        # e.g. liquid dosage form but "capsule" in name, or "MAX" in name but no cautions
        name = p["ProductName"]
        form = p.get("DosageForm", "")
        issues = []
        if form == "unknown":
            issues.append(("missing_dosage_form", "Dosage form could not be determined from source text.", "medium"))
        if "MAX" in name and not p.get("_cautions_list"):
            issues.append(("missing_max_caution", "Product name includes 'MAX' but no cautions text extracted.", "low"))
        if "Pregnancy" in name and not any("pregnan" in t.lower() for t in p.get("AvoidIfTags", [])):
            issues.append(("pregnancy_tag_missing", "Product name indicates pregnancy use but no pregnancy review tag set.", "high"))
        if p.get("AdultDose") and "take" not in p.get("AdultDose", "").lower():
            issues.append(("dose_malformed", f"AdultDose text does not contain 'take': {p['AdultDose'][:80]}", "medium"))
        # Pack size = "1 X" is suspicious (probably dose matched)
        if p.get("PackSize", "").strip() in {"1 capsule", "1 tablet", "1 soft gel", "1 lozenge", "1 sachet", "1 chewable tablet"}:
            issues.append(("pack_size_likely_dose", f"PackSize is '{p['PackSize']}' which likely came from dose line, not actual pack size.", "high"))
        # Strength unit missing on an ingredient
        for ing in p.get("_ingredients", []):
            if not ing.get("strength_unit"):
                issues.append(("ingredient_no_unit", f"Ingredient '{ing.get('ingredient_name')}' has no unit.", "low"))
        for issue in issues:
            ws.cell(row=ri, column=1, value=p["ProductID"])
            ws.cell(row=ri, column=2, value=name)
            ws.cell(row=ri, column=3, value=issue[0])
            ws.cell(row=ri, column=4, value=issue[1])
            ws.cell(row=ri, column=5, value=p.get("SourcePage", ""))
            ws.cell(row=ri, column=6, value=issue[2])
            for ci in range(1, 7):
                ws.cell(row=ri, column=ci).alignment = WRAP
            ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(no issues)")

    # --- Sheet 8: Inconsistent Word vs Excel data ---
    ws = wb.create_sheet("Word_Excel_Inconsistencies")
    headers = ["ProductID", "ProductName", "Issue", "Detail"]
    write_headers(ws, headers)
    ri = 2
    # For each product, compare what's in DOCX (authoritative) vs the XLSX (which is just a flatten)
    # The XLSX is the same text — so this is mainly about TOC page numbers matching the PDF
    for p in products:
        norm = p.get("ProductName_Normalised", "")
        # Did TOC list it?
        in_toc = norm in toc
        # Did DOCX have it as H1?
        in_docx = any(c.get("ProductName_Normalised") == norm for c in candidates["candidates"])
        if in_docx and not in_toc:
            ws.cell(row=ri, column=1, value=p["ProductID"])
            ws.cell(row=ri, column=2, value=p["ProductName"])
            ws.cell(row=ri, column=3, value="toc_missing")
            ws.cell(row=ri, column=4, value="Product appears in DOCX H1 but not in XLSX TOC.")
            for ci in range(1, 5):
                ws.cell(row=ri, column=ci).alignment = WRAP
            ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(no inconsistencies)")

    # --- Sheet 9: Products requiring pharmacist review ---
    ws = wb.create_sheet("Pharmacist_Review_Required")
    headers = [
        "ProductID", "ProductName", "DosageForm", "IngredientsCount",
        "AdultDose", "CautionsCount", "SourcePage", "Confidence",
        "ReviewPriority", "TriggerReason",
    ]
    write_headers(ws, headers)
    ri = 2
    for p in products:
        triggers = []
        if not p.get("AUSTL"):
            triggers.append("missing AUST L")
        if not p.get("_ingredients"):
            triggers.append("missing ingredients")
        if not p.get("AdultDose") and not p.get("ChildDose"):
            triggers.append("missing dose")
        if not p.get("_cautions_list"):
            triggers.append("no cautions extracted")
        if p.get("ExtractionConfidence") != "High":
            triggers.append(f"confidence={p.get('ExtractionConfidence')}")
        # Pregnancy product
        if "Pregnancy" in p["ProductName"]:
            triggers.append("pregnancy product")
        # B12 / Iron / Vit D (high-traffic products)
        if p.get("_ingredients"):
            inames = " ".join(i.get("ingredient_name", "") for i in p["_ingredients"]).lower()
            for keyword, label in [("iron", "iron"), ("vitamin d", "vitamin D"),
                                    ("vitamin b12", "B12"), ("magnesium", "magnesium"),
                                    ("calcium", "calcium"), ("probiotic", "probiotic"),
                                    ("fish oil", "omega-3"), ("coq10", "CoQ10")]:
                if keyword in inames and keyword not in [t.lower() for t in triggers]:
                    triggers.append(label + " product")
                    break
        if not triggers:
            continue
        # Compute priority
        if not p.get("AUSTL") or not p.get("_ingredients") or "Pregnancy" in p["ProductName"]:
            priority = "High"
        elif not p.get("_cautions_list") or not p.get("AdultDose"):
            priority = "Medium"
        else:
            priority = "Low"
        ws.cell(row=ri, column=1, value=p["ProductID"])
        ws.cell(row=ri, column=2, value=p["ProductName"])
        ws.cell(row=ri, column=3, value=p.get("DosageForm", ""))
        ws.cell(row=ri, column=4, value=len(p.get("_ingredients", [])))
        ws.cell(row=ri, column=5, value=(p.get("AdultDose", "")[:80] or "MISSING"))
        ws.cell(row=ri, column=6, value=len(p.get("_cautions_list", [])))
        ws.cell(row=ri, column=7, value=p.get("SourcePage", ""))
        ws.cell(row=ri, column=8, value=p.get("ExtractionConfidence", ""))
        ws.cell(row=ri, column=9, value=priority)
        ws.cell(row=ri, column=10, value=", ".join(triggers))
        for ci in range(1, 11):
            ws.cell(row=ri, column=ci).alignment = WRAP
        ri += 1
    if ri == 2:
        ws.cell(row=2, column=1, value="(nothing flagged)")

    # --- Sheet 10: Confidence distribution ---
    ws = wb.create_sheet("Confidence_Distribution")
    headers = ["Confidence", "Count", "Percent"]
    write_headers(ws, headers)
    counts = {"High": 0, "Medium": 0, "Low": 0}
    for p in products:
        c = p.get("ExtractionConfidence", "")
        if c in counts:
            counts[c] += 1
        else:
            counts["Medium"] += 1
    total = sum(counts.values()) or 1
    for ci, level in enumerate(["High", "Medium", "Low"], 1):
        ri = ci + 1
        ws.cell(row=ri, column=1, value=level)
        ws.cell(row=ri, column=2, value=counts[level])
        ws.cell(row=ri, column=3, value=f"{100*counts[level]/total:.1f}%")

    # Save
    out_path = OUTPUT / "validation_report.xlsx"
    wb.save(str(out_path))
    log.info("Wrote validation report: %s", out_path)

    # Also write a plain-text validation summary
    txt_path = OUTPUT / "validation_summary.txt"
    lines = [
        "Herbs of Gold — Validation Summary",
        "=" * 60,
        f"Generated: {__import__('datetime').datetime.now().isoformat(timespec='seconds')}",
        "",
        f"Total products exported: {len(products)}",
        f"  - High confidence: {counts['High']}",
        f"  - Medium confidence: {counts['Medium']}",
        f"  - Low confidence: {counts['Low']}",
        "",
        f"Products with ingredients: {sum(1 for p in products if p.get('_ingredients'))}",
        f"Products missing ingredients: {sum(1 for p in products if not p.get('_ingredients'))}",
        f"Products with dose: {sum(1 for p in products if p.get('AdultDose') or p.get('ChildDose'))}",
        f"Products missing dose: {sum(1 for p in products if not p.get('AdultDose') and not p.get('ChildDose'))}",
        f"Products with cautions: {sum(1 for p in products if p.get('_cautions_list'))}",
        f"Products missing cautions: {sum(1 for p in products if not p.get('_cautions_list'))}",
        f"Products missing AUST L: {sum(1 for p in products if not p.get('AUSTL'))} (all — AUSTL not in source)",
        f"Products missing dosage form: {sum(1 for p in products if p.get('DosageForm') in ('', 'unknown'))}",
        "",
        "Products requiring pharmacist review (prioritised):",
    ]
    review_list = []
    for p in products:
        triggers = []
        if not p.get("AUSTL"):
            triggers.append("missing AUST L")
        if not p.get("_ingredients"):
            triggers.append("missing ingredients")
        if not p.get("AdultDose") and not p.get("ChildDose"):
            triggers.append("missing dose")
        if not p.get("_cautions_list"):
            triggers.append("no cautions extracted")
        if p.get("ExtractionConfidence") == "Low":
            triggers.append("low confidence")
        if "Pregnancy" in p["ProductName"]:
            triggers.append("pregnancy product")
        if triggers:
            if not p.get("AUSTL") or not p.get("_ingredients") or "Pregnancy" in p["ProductName"]:
                priority = "HIGH"
            elif not p.get("_cautions_list") or not p.get("AdultDose"):
                priority = "MED"
            else:
                priority = "LOW"
            review_list.append((priority, p["ProductID"], p["ProductName"], triggers))
    review_list.sort(key=lambda x: ({"HIGH": 0, "MED": 1, "LOW": 2}[x[0]], x[1]))
    for prio, pid, pname, trigs in review_list[:40]:
        lines.append(f"  [{prio}] {pid}  {pname}  ({', '.join(trigs)})")
    if len(review_list) > 40:
        lines.append(f"  ... and {len(review_list) - 40} more")
    txt_path.write_text("\n".join(lines), encoding="utf-8")
    log.info("Wrote validation summary: %s", txt_path)

    log.info("Validation complete. %d products require review.", len(review_list))


if __name__ == "__main__":
    main()
