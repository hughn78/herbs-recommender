#!/usr/bin/env python3
"""04_identify_products.py — Build the canonical product candidate list.

Cross-references:
  - DOCX H1 product sections
  - XLSX TOC product -> page
  - PDF page index

Outputs:
  intermediate/product_candidates.csv — canonical product list with page hints
  intermediate/product_candidates.json — same data + cross-source flags
"""
from __future__ import annotations
import csv
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import (
    INTERMEDIATE, get_logger, normalise_name, make_product_id, BRAND
)

log = get_logger("04_identify_products")


def main():
    # Load sources
    docx_sections = json.loads(
        (INTERMEDIATE / "docx_sections.json").read_text(encoding="utf-8")
    )
    toc = json.loads(
        (INTERMEDIATE / "excel_product_pages.json").read_text(encoding="utf-8")
    )
    pdf_index = json.loads(
        (INTERMEDIATE / "pdf_page_index.json").read_text(encoding="utf-8")
    )
    page_to_product = {int(k): v for k, v in pdf_index["page_to_product"].items()}

    # Build TOC reverse: norm name -> product display name
    # (toc is already norm -> page; we need to use it as page -> norm)
    toc_norm_to_page = toc  # norm -> page

    # Build a unique list of products with metadata
    # Use DOCX sections as authoritative (they have structure)
    candidates = []
    seen_norms: dict[str, dict] = {}

    for idx, s in enumerate(docx_sections, start=1):
        name = s["product_name"]
        norm = s["product_name_normalised"]
        page = toc_norm_to_page.get(norm)
        in_toc = norm in toc_norm_to_page

        cand = {
            "ProductID": make_product_id(idx),
            "ProductName": name,
            "ProductName_Normalised": norm,
            "Brand": BRAND,
            "DocxHasSubsections": len(s["subsections"]) > 0,
            "DocxSubsectionCount": len(s["subsections"]),
            "DocxTableCount": len(s["tables"]),
            "XlsxTocPage": page if in_toc else None,
            "XlsxInToc": in_toc,
            "PdfPageHint": page if in_toc else None,
            "SourceCount": 1 + (1 if in_toc else 0),
        }
        candidates.append(cand)
        seen_norms[norm] = cand

    # Also pick up any TOC-only products (XLSX-only)
    toc_only_count = 0
    for norm, page in toc.items():
        if norm not in seen_norms:
            toc_only_count += 1
            log.warning("TOC-only product (no DOCX H1): %r on page %d", norm, page)
            # Skip from candidates — they may be front-matter (Notes, Contents)
            # But we record them in the JSON for reference

    log.info("Total candidates: %d (TOC-only extras: %d)", len(candidates), toc_only_count)

    # Write CSV
    csv_path = INTERMEDIATE / "product_candidates.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(candidates[0].keys()))
        w.writeheader()
        for c in candidates:
            w.writerow(c)
    log.info("Wrote %s", csv_path)

    # Write JSON
    json_path = INTERMEDIATE / "product_candidates.json"
    json_path.write_text(
        json.dumps({
            "candidates": candidates,
            "toc_only_extras": [
                {"normalised_name": n, "page": p} for n, p in toc.items()
                if n not in seen_norms
            ],
        }, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Wrote %s", json_path)

    # Cross-check: are all 103 products also in the TOC?
    in_both = sum(1 for c in candidates if c["XlsxInToc"])
    log.info("Products in BOTH DOCX and TOC: %d / %d", in_both, len(candidates))


if __name__ == "__main__":
    main()
