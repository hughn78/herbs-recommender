#!/usr/bin/env python3
"""01_extract_docx.py — Extract text and structure from herbsofgold_technical_manual.docx.

Outputs:
  extracted/docx_raw_text.txt        — full linear text (paragraphs + tables)
  intermediate/docx_sections.json    — structured list of H1 product sections
                                       with their body paragraphs & subheadings
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import SRC, EXTRACTED, INTERMEDIATE, get_logger, normalise_name

import docx
from docx.oxml.ns import qn

log = get_logger("01_extract_docx")

# Recognised H1 section headings that are NOT product names
NON_PRODUCT_SECTIONS = {
    "Contents", "COMPANY PROFILE", "QUALITY ASSURANCE", "TECHNICAL SUPPORT",
    "THE FUTURE", "Notes", "NOTES", "BIBLIOGRAPHY", "GLOSSARY",
    "Product suitability key",
}

# Recognised H2/H3 sub-section keywords that appear inside each product entry
PRODUCT_SUBSECTIONS = {
    "EACH CAPSULE CONTAINS",
    "EACH TABLET CONTAINS",
    "EACH FILM-COATED TABLET CONTAINS",
    "EACH VEGETABLE CAPSULE CONTAINS",
    "EACH CHEWABLE TABLET CONTAINS",
    "EACH SUBLINGUAL TABLET CONTAINS",
    "EACH SPRAY CONTAINS",
    "EACH 1mL CONTAINS",
    "EACH 1.5mL CONTAINS",
    "EACH 2mL CONTAINS",
    "EACH 2.5mL CONTAINS",
    "EACH 5mL CONTAINS",
    "EACH 10mL CONTAINS",
    "EACH DOSE CONTAINS",
    "EACH 1.2g CONTAINS",
    "EACH 1.6g CONTAINS",
    "EACH 5g CONTAINS",
    "EACH GRAM CONTAINS",
    "EACH 1 CAPSULE CONTAINS",
    "EACH 1 TABLET CONTAINS",
    "EACH 2 CAPSULES CONTAIN",
    "DIRECTIONS FOR USE",
    "FEATURES & BENEFITS",
    "FEATURES AND BENEFITS",
    "TECHNICAL INFORMATION",
    "DRUG INTERACTIONS",
    "DRUG INTERACTION",
    "CAUTIONS",
    "WARNINGS",
    "SIDE EFFECTS",
    "COMPANION PRODUCTS",
    "EACH CAPSULE CONTAINS:",
    "EACH TABLET CONTAINS:",
}


def is_heading(p) -> tuple[bool, str]:
    """Return (is_heading, level_name) for a paragraph."""
    if p.style is None:
        return False, ""
    n = p.style.name or ""
    if "Heading 1" in n:
        return True, "H1"
    if "Heading 2" in n:
        return True, "H2"
    if "Heading 3" in n:
        return True, "H3"
    return False, ""


def iter_block_items(parent):
    """Yield each paragraph and table child in document order."""
    from docx.document import Document as _Doc
    from docx.oxml.table import CT_Tbl
    from docx.oxml.text.paragraph import CT_P
    from docx.table import _Cell, Table
    from docx.text.paragraph import Paragraph

    if isinstance(parent, _Doc):
        parent_elm = parent.element.body
    else:
        parent_elm = parent

    for child in parent_elm.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, parent)
        elif isinstance(child, CT_Tbl):
            yield Table(child, parent)


def main():
    log.info("Opening DOCX: %s", SRC["docx"])
    d = docx.Document(str(SRC["docx"]))
    log.info("Paragraphs: %d | Tables: %d", len(d.paragraphs), len(d.tables))

    # --- 1. Linear raw text ---
    raw_lines = []
    sections: list[dict] = []
    current_product: dict | None = None
    current_subsection: str | None = None
    in_intro = True
    in_toc = False

    for block in iter_block_items(d):
        if isinstance(block, docx.text.paragraph.Paragraph):
            txt = block.text.strip()
            heading, level = is_heading(block)
            if heading:
                # H1 = product boundary (mostly)
                if level == "H1" and txt and txt not in NON_PRODUCT_SECTIONS:
                    # Save previous product
                    if current_product is not None:
                        sections.append(current_product)
                    in_toc = False
                    in_intro = False
                    # If we are already in the same product (page-break repeat), merge
                    if (current_product and
                        normalise_name(txt) == current_product["product_name_normalised"]):
                        # Same product repeated — just continue, don't reset subsections
                        current_subsection = None
                        raw_lines.append(f"\n## PRODUCT (cont.): {txt}\n")
                    else:
                        current_product = {
                            "product_name": txt,
                            "product_name_normalised": normalise_name(txt),
                            "subsections": [],
                            "tables": [],
                        }
                        current_subsection = None
                        raw_lines.append(f"\n## PRODUCT: {txt}\n")
                elif level == "H1" and txt == "Contents":
                    in_toc = True
                    current_product = None
                    current_subsection = None
                    raw_lines.append("\n## Contents (TOC)\n")
                elif level == "H1":
                    in_toc = False
                    in_intro = True
                    if current_product is not None:
                        sections.append(current_product)
                    current_product = None
                    current_subsection = None
                    raw_lines.append(f"\n## SECTION: {txt}\n")
                else:
                    # H2/H3 sub-section inside a product
                    label = txt.upper().rstrip(":")
                    if current_product is not None and (
                        label in PRODUCT_SUBSECTIONS or level == "H3"
                    ):
                        current_subsection = label
                        current_product["subsections"].append({
                            "heading": txt,
                            "level": level,
                            "text": "",
                        })
                    raw_lines.append(f"\n### {txt}\n")
            else:
                if not txt:
                    continue
                if in_toc:
                    raw_lines.append(txt)
                elif current_product is not None:
                    raw_lines.append(txt)
                    if current_subsection is not None and current_product["subsections"]:
                        current_product["subsections"][-1]["text"] += txt + "\n"
                else:
                    raw_lines.append(txt)
        elif isinstance(block, docx.table.Table):
            tbl_text_rows = []
            for row in block.rows:
                cells = [c.text.replace("\n", " ").strip() for c in row.cells]
                tbl_text_rows.append(cells)
            raw_lines.append("\n[TABLE]\n" + "\n".join(" | ".join(r) for r in tbl_text_rows) + "\n[/TABLE]\n")
            if current_product is not None:
                current_product["tables"].append(tbl_text_rows)
            else:
                # Tables in front matter (TOC etc.) — still record
                pass

    if current_product is not None:
        sections.append(current_product)

    # ---- Post-process: merge consecutive same-name H1s (page-break repeats) ----
    merged: list[dict] = []
    for s in sections:
        if merged and merged[-1]["product_name_normalised"] == s["product_name_normalised"]:
            # Append subsections and tables; the longer subsection text wins
            existing = {x["heading"].upper() for x in merged[-1]["subsections"]}
            for ss in s["subsections"]:
                if ss["heading"].upper() in existing:
                    # Append to existing entry's text
                    for ex in merged[-1]["subsections"]:
                        if ex["heading"].upper() == ss["heading"].upper():
                            ex["text"] += "\n" + ss["text"]
                            break
                else:
                    merged[-1]["subsections"].append(ss)
                    existing.add(ss["heading"].upper())
            merged[-1]["tables"].extend(s["tables"])
        else:
            merged.append(s)
    sections = merged

    raw_text = "\n".join(raw_lines)
    (EXTRACTED / "docx_raw_text.txt").write_text(raw_text, encoding="utf-8")
    log.info("Wrote raw text: %d chars, %d lines", len(raw_text), len(raw_lines))

    (INTERMEDIATE / "docx_sections.json").write_text(
        json.dumps(sections, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Wrote sections: %d product sections", len(sections))

    # Quick summary
    from collections import Counter
    subsections = Counter()
    for s in sections:
        for ss in s["subsections"]:
            subsections[ss["heading"]] += 1
    log.info("Subsection frequency (top 15):")
    for k, v in subsections.most_common(15):
        log.info("  %4d  %s", v, k)

    # Record product name list
    name_list = [s["product_name"] for s in sections]
    (INTERMEDIATE / "docx_product_names.json").write_text(
        json.dumps(name_list, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Product names: %d", len(name_list))


if __name__ == "__main__":
    main()
