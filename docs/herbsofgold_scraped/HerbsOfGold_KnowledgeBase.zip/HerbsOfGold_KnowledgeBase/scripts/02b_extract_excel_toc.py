#!/usr/bin/env python3
"""02b_extract_excel_toc.py — Extract the product->page map from the Excel TOC.

The XLSX Table 1 sheet contains a flattened TOC across columns. This script
parses it to build a product -> page number mapping for cross-validation.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from _lib import SRC, INTERMEDIATE, get_logger, normalise_name

import openpyxl

log = get_logger("02b_extract_excel_toc")


def main():
    log.info("Opening XLSX: %s", SRC["xlsx"])
    wb = openpyxl.load_workbook(str(SRC["xlsx"]), data_only=True, read_only=True)
    ws = wb["Table 1"]

    # The TOC occupies rows 6..~50, in 3 columns:
    #   col 0 (name) + col 12 (page)
    #   col 17 (name) + col 35 (page)
    #   col 42 (name) + col 54 (page)
    COL_PAIRS = [(0, 12), (17, 35), (42, 54)]
    product_pages: list[tuple[str, int]] = []
    rows = list(ws.iter_rows(values_only=True))
    for r in rows[6:60]:
        for name_col, page_col in COL_PAIRS:
            if name_col < len(r) and page_col < len(r):
                name = r[name_col]
                page = r[page_col]
                if (isinstance(name, str) and name.strip() and
                    isinstance(page, (int, float)) and 1 <= int(page) <= 250):
                    product_pages.append((name.strip(), int(page)))

    # Dedupe and normalise
    seen: dict[str, int] = {}
    for name, page in product_pages:
        n = normalise_name(name)
        if n and n not in seen:
            seen[n] = page

    log.info("Extracted %d product->page pairs (unique: %d)", len(product_pages), len(seen))

    (INTERMEDIATE / "excel_product_pages.json").write_text(
        json.dumps(seen, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.info("Wrote excel_product_pages.json")


if __name__ == "__main__":
    main()
