"""
Shared utilities for Herbs of Gold knowledge base extraction.

Defines:
- File paths
- Logging configuration
- Product name normalisation
- Ingredient classification helpers
"""
from __future__ import annotations
import logging
import re
import unicodedata
from pathlib import Path

# ----- Paths -----
ROOT = Path("/Users/hughn78/herbsofgold_scraped/HerbsOfGold_KnowledgeBase")
SCRAPED = Path("/Users/hughn78/herbsofgold_scraped")
SRC = {
    "pdf": SCRAPED / "herbsofgold_technical_manual.pdf",
    "docx": SCRAPED / "herbsofgold_technical_manual.docx",
    "xlsx": SCRAPED / "herbsofgold_technical_manual.xlsx",
    "md": SCRAPED / "markdown" / "herbsofgold_technical_manual.md",
}
EXTRACTED = ROOT / "extracted"
INTERMEDIATE = ROOT / "intermediate"
OUTPUT = ROOT / "output"
LOGS = ROOT / "logs"
SCRIPTS = ROOT / "scripts"

for d in [EXTRACTED, INTERMEDIATE, OUTPUT, LOGS, SCRIPTS,
          EXTRACTED / "excel_sheets"]:
    d.mkdir(parents=True, exist_ok=True)

# ----- Logging -----
def get_logger(name: str) -> logging.Logger:
    log = logging.getLogger(name)
    if not log.handlers:
        log.setLevel(logging.INFO)
        fh = logging.FileHandler(LOGS / f"{name}.log", mode="a", encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s"))
        log.addHandler(fh)
        sh = logging.StreamHandler()
        sh.setFormatter(logging.Formatter("%(levelname)-7s | %(message)s"))
        log.addHandler(sh)
    return log

# ----- Normalisation -----
def normalise_name(s: str) -> str:
    """Lowercase, strip, collapse whitespace, remove punctuation. Used for dedup."""
    if not s:
        return ""
    s = unicodedata.normalize("NFKD", s)
    s = s.lower().strip()
    s = re.sub(r"[\u2018\u2019\u201c\u201d]", "'", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

# ----- Ingredient classification (heuristic) -----
INGREDIENT_RULES: list[tuple[str, str]] = [
    # (substring, type)
    (r"\bvitamin\s+[abcdke]|\bfolate|\bfolic\s+acid|\bniacin|\bbiotin|\bthiamine|\briboflavin|\bcobalamin|\bpyridoxine|\bcholecalciferol|\bmenaquinone|\btocopherol|\bcalcitriol|\bcarotene|\bretinol", "vitamin"),
    (r"\bmagnesium|\bcalcium|\biron|\bzinc|\bselenium|\bchromium|\bmanganese|\bpotassium|\bsodium|\bcopper|\biodine|\bmolybdenum|\bboron|\bsilicon", "mineral"),
    (r"\bcarnitine|\btyrosine|\btaurine|\blysine|\barginine|\bmethionine|\bcysteine|\bglutamine|\btryptophan|\bphenylalanine|\bglycine|\btheanine|\bhistidine", "amino_acid"),
    (r"\blactobacillus|\bbifidobacterium|\bsaccharomyces|\bprobiotic|\bcfu", "probiotic"),
    (r"\bamylase|\blipase|\bprotease|\bbromelain|\bpepsin|\btrypsin|\bpapain|\bcellulase|\blactase|\benzyme", "enzyme"),
    (r"\bomega[\s-]*3|\bepa|\bdha|\bfish\s+oil|\bflaxseed|\bevening\s+primrose|\bsea\s+buckthorn|\bborage", "oil"),
    (r"\bextract|\bherb|\broot|\bleaf|\bbark|\bflower|\brhizome|\bfruit|\bseed|\bginkgo|\bechinacea|\st\.?\s*john|\svalerian|\bginseng|\bbrahmi|\bbacopa|\bsaw\s+palmetto|\bsilymarin|\bmilk\s+thistle|\bchamomile|\bskullcap|\boats|\bpassionflower|\blemon\s+balm|\bhawthorn|\bblack\s+cohosh|\bvitex|\bsage|\brosemary|\bthyme|\bgarlic|\bturmeric|\bginger|\bfenugreek|\bhops|\bgriffonia|\bsaffron|\breishi|\bchaga|\blion's\s+mane|\bcordyceps|\bmaitake|\bshiitake|\btribulus|\bwithania|\basiwagandha|\bamla|\bgoji|\bacai|\bnoni|\bastragalus|\belderberry|\bberry|\bpepermint|\bspearmint|\bfennel|\bdandelion|\bnettle|\bhorse\s+chestnut|\bcelery\s+seed|\bdevil's\s+claw|\bglucomannan", "herb"),
]

def classify_ingredient(name: str) -> str:
    if not name:
        return "unknown"
    n = name.lower()
    for pattern, label in INGREDIENT_RULES:
        if re.search(pattern, n):
            return label
    return "other"

# ----- AUST L regex -----
AUSTL_RE = re.compile(r"\bAUST\s*L\s*[:#]?\s*(\d{4,6})\b", re.IGNORECASE)

# ----- Strength parsing -----
# Matches: "500mg", "1.5 g", "10 mcg", "1000 IU", "50 µg", "10 billion CFU"
STRENGTH_RE = re.compile(
    r"(?P<amount>[\d.,]+(?:\s*x\s*10[\^]?\d+)?(?:\s*(?:million|billion|trillion))?)\s*"
    r"(?P<unit>mg|mcg|µg|ug|g|kg|iu|ml|iu|cfu|billion|million|trillion)\b",
    re.IGNORECASE,
)

# ----- Brand / display -----
BRAND = "Herbs of Gold"

# ----- Product order index for stable IDs -----
def make_product_id(index: int) -> str:
    return f"HOG-{index:04d}"
